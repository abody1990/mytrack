package com.mytrack.app

import android.content.Context
import android.content.res.Configuration

/** إعدادات التطبيق. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** 0 تلقائي حسب الجهاز، 1 فاتح، 2 داكن */
    fun theme(c: Context) = p(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = p(c).edit().putInt("theme", v).apply()

    /** دقايق الثبات قبل الإيقاف التلقائي (0 = معطّل) */
    fun autoStopMin(c: Context) = p(c).getInt("autostop", 60)
    fun setAutoStop(c: Context, v: Int) = p(c).edit().putInt("autostop", v).apply()

    /** تنبيه "عم تتحرك والتسجيل مطفي" */
    fun reminder(c: Context) = p(c).getBoolean("reminder", false)
    fun setReminder(c: Context, v: Boolean) = p(c).edit().putBoolean("reminder", v).apply()

    /** تخفيف دقة الـ GPS لما البطارية تضعف */
    fun lowBattery(c: Context) = p(c).getBoolean("lowbat", true)
    fun setLowBattery(c: Context, v: Boolean) = p(c).edit().putBoolean("lowbat", v).apply()

    fun isDark(c: Context): Boolean = when (theme(c)) {
        1 -> false
        2 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }
}
