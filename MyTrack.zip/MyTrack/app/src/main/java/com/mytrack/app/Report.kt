package com.mytrack.app

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DayStats(
    val trips: Int,
    val meters: Double,
    val seconds: Long,
    val movingSeconds: Long,
    val maxKmh: Double,
    val visits: List<Visit>
)

object Report {

    /** بداية ونهاية اليوم اللي بيحتوي الوقت [ref]. */
    fun dayBounds(ref: Long): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ref
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val from = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return Pair(from, cal.timeInMillis)
    }

    fun stats(db: TrackDb, from: Long, to: Long): DayStats {
        var trips = 0
        var meters = 0.0
        var secs = 0L
        var moving = 0L
        var maxMs = 0.0
        val res = FloatArray(1)
        for (t in db.tripsBetween(from, to)) {
            val pts = db.points(t.id)
            if (pts.size < 2) continue
            trips++
            secs += (pts.last().t - pts.first().t) / 1000
            for (i in 1 until pts.size) {
                val a = pts[i - 1]
                val b = pts[i]
                val dt = (b.t - a.t) / 1000.0
                if (dt <= 0) continue
                Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, res)
                val d = res[0].toDouble()
                val v = d / dt
                if (v > 70) continue // قفزة GPS، منتجاهلها
                meters += d
                if (v > 0.5) moving += dt.toLong()
                val sp = if (b.spd > 0) b.spd else v
                if (sp <= 70 && sp > maxMs) maxMs = sp
            }
        }
        return DayStats(trips, meters, secs, moving, maxMs * 3.6, db.visits(from, to))
    }

    fun km(meters: Double): String = String.format(Locale.US, "%.2f", meters / 1000)

    fun dur(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return when {
            h > 0 -> "${h}س ${m}د"
            m > 0 -> "${m}د"
            else -> "${sec}ث"
        }
    }

    fun clock(sec: Long): String {
        val s = if (sec < 0) 0 else sec
        val h = s / 3600
        val m = (s % 3600) / 60
        val r = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, r)
        else String.format(Locale.US, "%02d:%02d", m, r)
    }

    fun placeLabel(v: Visit): String {
        val name = v.name ?: "مكان (بانتظار الإنترنت لمعرفة الاسم)"
        return if (!v.type.isNullOrBlank()) "${v.type}: $name" else name
    }

    fun text(s: DayStats, from: Long): String {
        val weekday = SimpleDateFormat("EEEE", Locale.forLanguageTag("ar")).format(Date(from))
        val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(from))
        val hm = SimpleDateFormat("HH:mm", Locale.US)
        val sb = StringBuilder()
        sb.append("📅 $weekday $date\n\n")
        if (s.trips == 0) {
            sb.append("ما في رحلات مسجّلة بهاد اليوم.")
        } else {
            val avg = if (s.movingSeconds > 0) s.meters / s.movingSeconds * 3.6 else 0.0
            sb.append("🚶 المسافة: ${km(s.meters)} كم\n")
            sb.append("🧭 عدد الرحلات: ${s.trips}\n")
            sb.append("⏱ مدة التسجيل: ${dur(s.seconds)}\n")
            sb.append("👟 مدة الحركة: ${dur(s.movingSeconds)}\n")
            sb.append("⚡ متوسط السرعة: ${String.format(Locale.US, "%.1f", avg)} كم/س\n")
            sb.append("🚀 أقصى سرعة: ${String.format(Locale.US, "%.0f", s.maxKmh)} كم/س\n")
        }
        if (s.visits.isNotEmpty()) {
            sb.append("\n📌 الأماكن اللي وقفت فيها:\n")
            for (v in s.visits) {
                val mins = (v.leave - v.arrive) / 60000
                sb.append("• ${hm.format(Date(v.arrive))} → ${hm.format(Date(v.leave))}  ${placeLabel(v)} (${dur(mins * 60)})\n")
            }
        }
        return sb.toString().trimEnd()
    }
}
