package com.mytrack.app

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class TripAnalysis(
    val meters: Double,
    val seconds: Long,
    val moving: Long,
    val maxKmh: Double,
    val walkM: Double,
    val bikeM: Double,
    val carM: Double
)

data class DayStats(
    val trips: Int,
    val meters: Double,
    val seconds: Long,
    val movingSeconds: Long,
    val maxKmh: Double,
    val walkM: Double,
    val bikeM: Double,
    val carM: Double,
    val visits: List<Visit>
)

object Report {

    /** حدود نوع الحركة بالمتر/ثانية: مشي ≤ 8 كم/س، دراجة/جري ≤ 25 كم/س، وما فوق مركبة. */
    const val WALK_MAX = 2.2
    const val BIKE_MAX = 7.0

    /** بداية ونهاية اليوم اللي بيحتوي الوقت [ref]. */
    fun dayBounds(ref: Long): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ref
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val from = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return Pair(from, cal.timeInMillis)
    }

    fun analyze(pts: List<Pt>): TripAnalysis {
        var meters = 0.0
        var moving = 0L
        var maxMs = 0.0
        var walk = 0.0
        var bike = 0.0
        var car = 0.0
        val res = FloatArray(1)
        for (i in 1 until pts.size) {
            val a = pts[i - 1]
            val b = pts[i]
            val dt = (b.t - a.t) / 1000.0
            if (dt <= 0) continue
            Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, res)
            val d = res[0].toDouble()
            val v = d / dt
            if (v > 70) continue // قفزة GPS، منتجاهلها
            meters += d
            if (v > 0.5) {
                moving += dt.toLong()
                when {
                    v <= WALK_MAX -> walk += d
                    v <= BIKE_MAX -> bike += d
                    else -> car += d
                }
            }
            val sp = if (b.spd > 0) b.spd else v
            if (sp <= 70 && sp > maxMs) maxMs = sp
        }
        val secs = if (pts.size >= 2) (pts.last().t - pts.first().t) / 1000 else 0L
        return TripAnalysis(meters, secs, moving, maxMs * 3.6, walk, bike, car)
    }

    fun typeEmoji(a: TripAnalysis): String = when {
        a.walkM + a.bikeM + a.carM <= 0.0 -> ""
        a.walkM >= a.bikeM && a.walkM >= a.carM -> "🚶"
        a.bikeM >= a.carM -> "🚴"
        else -> "🚗"
    }

    /** سرعة كل نقطة (م/ث) بعد تنعيمها، لتلوين المسار. */
    fun segSpeeds(pts: List<Pt>): DoubleArray {
        val n = pts.size
        val raw = DoubleArray(n)
        val res = FloatArray(1)
        for (i in 1 until n) {
            val dt = (pts[i].t - pts[i - 1].t) / 1000.0
            var v = 0.0
            if (dt > 0) {
                Location.distanceBetween(pts[i - 1].lat, pts[i - 1].lon, pts[i].lat, pts[i].lon, res)
                v = res[0] / dt
            }
            raw[i] = if (v > 70) 0.0 else v
        }
        if (n > 1) raw[0] = raw[1]
        val out = DoubleArray(n)
        for (i in 0 until n) {
            var s = 0.0
            var c = 0
            for (j in maxOf(0, i - 2)..minOf(n - 1, i + 2)) {
                s += raw[j]
                c++
            }
            out[i] = s / c
        }
        return out
    }

    fun stats(db: TrackDb, from: Long, to: Long): DayStats {
        var trips = 0
        var meters = 0.0
        var secs = 0L
        var moving = 0L
        var maxKmh = 0.0
        var walk = 0.0
        var bike = 0.0
        var car = 0.0
        for (t in db.tripsBetween(from, to)) {
            val pts = db.points(t.id)
            if (pts.size < 2) continue
            val a = analyze(pts)
            trips++
            meters += a.meters
            secs += a.seconds
            moving += a.moving
            if (a.maxKmh > maxKmh) maxKmh = a.maxKmh
            walk += a.walkM
            bike += a.bikeM
            car += a.carM
        }
        return DayStats(trips, meters, secs, moving, maxKmh, walk, bike, car, db.visits(from, to))
    }

    /** إحصائيات آخر [days] يوم، من الأقدم للأحدث. */
    fun daily(db: TrackDb, days: Int): List<Pair<Long, DayStats>> {
        val out = ArrayList<Pair<Long, DayStats>>()
        val cal = Calendar.getInstance()
        cal.timeInMillis = dayBounds(System.currentTimeMillis()).first
        cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
        for (i in 0 until days) {
            val from = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
            out.add(Pair(from, stats(db, from, cal.timeInMillis)))
        }
        return out
    }

    fun km(meters: Double): String = String.format(Locale.US, "%.2f", meters / 1000)

    fun dur(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return when {
            h > 0 -> "${h}س ${m}د"
            m > 0 -> "${m}د"
            else -> "${sec}ث"
        }
    }

    fun clock(sec: Long): String {
        val s = if (sec < 0) 0 else sec
        val h = s / 3600
        val m = (s % 3600) / 60
        val r = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, r)
        else String.format(Locale.US, "%02d:%02d", m, r)
    }

    fun placeLabel(v: Visit): String {
        val name = v.name ?: "مكان (بانتظار الإنترنت لمعرفة الاسم)"
        return if (!v.type.isNullOrBlank()) "${v.type}: $name" else name
    }

    fun text(s: DayStats, from: Long): String {
        val weekday = SimpleDateFormat("EEEE", Locale.forLanguageTag("ar")).format(Date(from))
        val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(from))
        val hm = SimpleDateFormat("HH:mm", Locale.US)
        val sb = StringBuilder()
        sb.append("📅 $weekday $date\n\n")
        if (s.trips == 0) {
            sb.append("ما في رحلات مسجّلة بهاد اليوم.")
        } else {
            val avg = if (s.movingSeconds > 0) s.meters / s.movingSeconds * 3.6 else 0.0
            sb.append("📏 المسافة: ${km(s.meters)} كم\n")
            sb.append("🧭 عدد الرحلات: ${s.trips}\n")
            sb.append("⏱ مدة التسجيل: ${dur(s.seconds)}\n")
            sb.append("👟 مدة الحركة: ${dur(s.movingSeconds)}\n")
            sb.append("⚡ متوسط السرعة: ${String.format(Locale.US, "%.1f", avg)} كم/س\n")
            sb.append("🚀 أقصى سرعة: ${String.format(Locale.US, "%.0f", s.maxKmh)} كم/س\n")
            if (s.walkM + s.bikeM + s.carM > 0) {
                sb.append("\n🚶 مشي: ${km(s.walkM)} كم\n")
                sb.append("🚴 دراجة/جري: ${km(s.bikeM)} كم\n")
                sb.append("🚗 مركبة: ${km(s.carM)} كم\n")
            }
        }
        if (s.visits.isNotEmpty()) {
            sb.append("\n📌 الأماكن اللي وقفت فيها:\n")
            for (v in s.visits) {
                val mins = (v.leave - v.arrive) / 60000
                sb.append("• ${hm.format(Date(v.arrive))} → ${hm.format(Date(v.leave))}  ${placeLabel(v)} (${dur(mins * 60)})\n")
            }
        }
        return sb.toString().trimEnd()
    }
}
