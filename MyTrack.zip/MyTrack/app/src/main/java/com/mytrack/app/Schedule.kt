package com.mytrack.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

/** جدولة التسجيل التلقائي كل يوم من ساعة كذا لساعة كذا. */
object Schedule {
    const val ACTION_START = "com.mytrack.app.SCHED_START"
    const val ACTION_END = "com.mytrack.app.SCHED_END"

    private fun prefs(c: Context) = c.getSharedPreferences("schedule", Context.MODE_PRIVATE)

    fun enabled(c: Context) = prefs(c).getBoolean("on", false)
    fun startMin(c: Context) = prefs(c).getInt("start", 8 * 60)
    fun endMin(c: Context) = prefs(c).getInt("end", 18 * 60)

    fun save(c: Context, on: Boolean, start: Int, end: Int) {
        prefs(c).edit().putBoolean("on", on).putInt("start", start).putInt("end", end).apply()
    }

    fun fmt(min: Int): String = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

    /** هل الوقت الحالي ضمن فترة التسجيل؟ (بيدعم الفترات اللي بتعدّي منتصف الليل) */
    fun inWindow(c: Context): Boolean {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = startMin(c)
        val e = endMin(c)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    private fun nextTrigger(min: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, min / 60)
        cal.set(Calendar.MINUTE, min % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 60_000) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pending(c: Context, code: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, code, Intent(c, ScheduleReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun scheduleAll(c: Context) {
        if (!enabled(c)) {
            cancelAll(c)
            return
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 20, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        set(am, show, nextTrigger(startMin(c)), pending(c, 10, ACTION_START))
        set(am, show, nextTrigger(endMin(c)), pending(c, 11, ACTION_END))
    }

    /** وقت دقيق إذا أندرويد سمح، وإلا وقت تقريبي (ممكن يتأخر دقايق) بدل ما يسكّر التطبيق. */
    private fun set(am: AlarmManager, show: PendingIntent, at: Long, pi: PendingIntent) {
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
        } catch (_: SecurityException) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (_: Throwable) {
            }
        }
    }

    fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, 10, ACTION_START))
        am.cancel(pending(c, 11, ACTION_END))
    }
}

class ScheduleReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val c = context.applicationContext
        when (intent.action) {
            Schedule.ACTION_START -> {
                Schedule.scheduleAll(c)
                if (Schedule.enabled(c) && !TrackingService.recording) startRecording(c)
            }
            Schedule.ACTION_END -> {
                Schedule.scheduleAll(c)
                endRecording(c)
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                Schedule.scheduleAll(c)
                Reminder.sync(c)
                TrackWidget.update(c)
                if (Schedule.enabled(c) && Schedule.inWindow(c) && !TrackingService.recording) startRecording(c)
            }
            else -> {}
        }
    }

    private fun startRecording(c: Context) {
        try {
            ContextCompat.startForegroundService(c, Intent(c, TrackingService::class.java).putExtra("auto", true))
        } catch (_: Throwable) {
            // أندرويد منع التشغيل من الخلفية: نبّه المستخدم يفتح التطبيق
            Notifs.post(c, 4, "حان وقت التسجيل", "اضغط لفتح التطبيق وبدء التسجيل", "autostart")
        }
    }

    private fun endRecording(c: Context) {
        // بنوقف بس التسجيل اللي بدأ تلقائياً؛ اللي بدأته انت بإيدك بيضل شغّال
        if (TrackingService.recording && TrackingService.autoStarted) {
            try {
                c.startService(Intent(c, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
            } catch (_: Throwable) {
            }
        }
        try {
            val (from, to) = Report.dayBounds(System.currentTimeMillis())
            val s = Report.stats(TrackDb(c), from, to)
            val text = if (s.trips == 0) "ما في رحلات مسجّلة اليوم."
            else "${Report.km(s.meters)} كم • ${s.trips} رحلة • ${s.visits.size} مكان\nاضغط لعرض التقرير الكامل."
            Notifs.post(c, 3, "📊 تقريرك اليومي جاهز", text, "report")
        } catch (_: Throwable) {
        }
    }
}
