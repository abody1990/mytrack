package com.mytrack.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import java.util.Locale

/** ويدجت للشاشة الرئيسية: زر بدء/إيقاف التسجيل بدون فتح التطبيق. */
class TrackWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        update(context)
    }

    companion object {
        fun update(c: Context) {
            try {
                val app = c.applicationContext
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, TrackWidget::class.java))
                if (ids.isEmpty()) return

                val rec = TrackingService.recording
                val rv = RemoteViews(app.packageName, R.layout.widget)
                rv.setTextViewText(R.id.w_title, if (rec) "⏹ إيقاف التسجيل" else "⏺ ابدأ التسجيل")
                rv.setTextViewText(
                    R.id.w_info,
                    if (rec) String.format(
                        Locale.US, "%.2f كم  •  %.0f كم/س",
                        TrackingService.distance / 1000f, TrackingService.speedKmh
                    ) else "مساري"
                )
                rv.setInt(
                    R.id.w_root, "setBackgroundResource",
                    if (rec) R.drawable.widget_bg_red else R.drawable.widget_bg_green
                )

                val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                val pi = if (rec) {
                    PendingIntent.getService(
                        app, 40,
                        Intent(app, TrackingService::class.java).setAction(TrackingService.ACTION_STOP), flags
                    )
                } else if (Build.VERSION.SDK_INT >= 26) {
                    PendingIntent.getForegroundService(app, 41, Intent(app, TrackingService::class.java), flags)
                } else {
                    PendingIntent.getService(app, 41, Intent(app, TrackingService::class.java), flags)
                }
                rv.setOnClickPendingIntent(R.id.w_root, pi)
                mgr.updateAppWidget(ids, rv)
            } catch (_: Throwable) {
            }
        }
    }
}
