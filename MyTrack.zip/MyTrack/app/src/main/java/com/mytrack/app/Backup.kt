package com.mytrack.app

import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader

/** نسخة احتياطية: كل الرحلات والنقاط والأماكن بملف JSON واحد، وبتنضاف عند الاستعادة بدون تكرار. */
object Backup {

    fun write(db: TrackDb, out: File) {
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            val j = JsonWriter(w)
            j.beginObject()
            j.name("app").value("MyTrack")
            j.name("version").value(1L)

            j.name("trips").beginArray()
            for (t in db.trips().reversed()) {
                j.beginObject()
                j.name("started").value(t.start)
                j.name("ended").value(t.end)
                j.name("points").beginArray()
                for (p in db.points(t.id)) {
                    j.beginArray()
                    j.value(p.lat)
                    j.value(p.lon)
                    j.value(p.ele)
                    j.value(p.t)
                    j.value(p.spd)
                    j.endArray()
                }
                j.endArray()
                j.name("visits").beginArray()
                for (v in db.visitsOfTrip(t.id)) {
                    j.beginObject()
                    j.name("lat").value(v.lat)
                    j.name("lon").value(v.lon)
                    j.name("arrive").value(v.arrive)
                    j.name("leave").value(v.leave)
                    j.name("name").value(v.name)
                    j.name("type").value(v.type)
                    j.endObject()
                }
                j.endArray()
                j.endObject()
            }
            j.endArray()

            j.name("places").beginArray()
            for (p in db.savedPlaces()) {
                j.beginObject()
                j.name("name").value(p.name)
                j.name("lat").value(p.lat)
                j.name("lon").value(p.lon)
                j.endObject()
            }
            j.endArray()

            j.endObject()
            j.flush()
        }
    }

    /** بيرجّع عدد الرحلات اللي انضافت. */
    fun restore(db: TrackDb, input: InputStream): Int {
        val r = JsonReader(InputStreamReader(input, Charsets.UTF_8))
        var added = 0
        db.tx {
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "trips" -> {
                        r.beginArray()
                        while (r.hasNext()) {
                            if (readTrip(r, db)) added++
                        }
                        r.endArray()
                    }
                    "places" -> {
                        r.beginArray()
                        while (r.hasNext()) readPlace(r, db)
                        r.endArray()
                    }
                    else -> r.skipValue()
                }
            }
            r.endObject()
        }
        return added
    }

    private fun strOrNull(r: JsonReader): String? {
        if (r.peek() == JsonToken.NULL) {
            r.nextNull()
            return null
        }
        return r.nextString()
    }

    private fun readTrip(r: JsonReader, db: TrackDb): Boolean {
        var started = 0L
        var ended = 0L
        val pts = ArrayList<Pt>()
        val vis = ArrayList<Visit>()
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "started" -> started = r.nextLong()
                "ended" -> ended = r.nextLong()
                "points" -> {
                    r.beginArray()
                    while (r.hasNext()) {
                        r.beginArray()
                        val lat = r.nextDouble()
                        val lon = r.nextDouble()
                        val ele = r.nextDouble()
                        val t = r.nextLong()
                        val spd = r.nextDouble()
                        r.endArray()
                        pts.add(Pt(lat, lon, ele, t, spd))
                    }
                    r.endArray()
                }
                "visits" -> {
                    r.beginArray()
                    while (r.hasNext()) {
                        var lat = 0.0
                        var lon = 0.0
                        var arrive = 0L
                        var leave = 0L
                        var name: String? = null
                        var type: String? = null
                        r.beginObject()
                        while (r.hasNext()) {
                            when (r.nextName()) {
                                "lat" -> lat = r.nextDouble()
                                "lon" -> lon = r.nextDouble()
                                "arrive" -> arrive = r.nextLong()
                                "leave" -> leave = r.nextLong()
                                "name" -> name = strOrNull(r)
                                "type" -> type = strOrNull(r)
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()
                        vis.add(Visit(0, 0, lat, lon, arrive, leave, name, type))
                    }
                    r.endArray()
                }
                else -> r.skipValue()
            }
        }
        r.endObject()

        if (started == 0L || pts.isEmpty() || db.hasTrip(started)) return false
        val end = if (ended > 0) ended else pts.last().t
        val id = db.insertTrip(started, end)
        for (p in pts) db.addPoint(id, p.lat, p.lon, p.ele, p.t, p.spd)
        for (v in vis) db.insertVisitRaw(id, v.lat, v.lon, v.arrive, v.leave, v.name, v.type)
        return true
    }

    private fun readPlace(r: JsonReader, db: TrackDb) {
        var name = ""
        var lat = 0.0
        var lon = 0.0
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "name" -> name = strOrNull(r) ?: ""
                "lat" -> lat = r.nextDouble()
                "lon" -> lon = r.nextDouble()
                else -> r.skipValue()
            }
        }
        r.endObject()
        if (name.isNotBlank()) {
            val exists = db.savedPlaces().any { it.name == name && Math.abs(it.lat - lat) < 0.0005 && Math.abs(it.lon - lon) < 0.0005 }
            if (!exists) db.addSavedPlace(name, lat, lon)
        }
    }
}
