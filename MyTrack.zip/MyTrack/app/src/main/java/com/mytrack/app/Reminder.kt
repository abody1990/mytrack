package com.mytrack.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * تنبيه "نسيت تبدأ التسجيل": بنراقب الموقع بشكل خفيف (كل دقيقتين تقريباً، بدون GPS)،
 * وإذا لاحظنا إنك عم تتحرك والتسجيل مطفي بنبعتلك إشعار.
 */
object Reminder {
    private const val ACTION = "com.mytrack.app.MOVE"

    fun pending(c: Context): PendingIntent {
        // النظام بيضيف بيانات الموقع للـ Intent، فلازم يكون قابل للتعديل (Mutable)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(
            c, 30, Intent(c, MovementReceiver::class.java).setAction(ACTION), flags
        )
    }

    @SuppressLint("MissingPermission")
    fun sync(c: Context) {
        val app = c.applicationContext
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            lm.removeUpdates(pending(app))
        } catch (_: Throwable) {
        }
        if (!Prefs.reminder(app)) return
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val provider = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                LocationManager.NETWORK_PROVIDER else LocationManager.PASSIVE_PROVIDER
            lm.requestLocationUpdates(provider, 120_000L, 80f, pending(app))
        } catch (_: Throwable) {
        }
    }
}

class MovementReceiver : BroadcastReceiver() {

    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        val c = context.applicationContext
        if (!Prefs.reminder(c)) return
        val loc = intent.extras?.get(LocationManager.KEY_LOCATION_CHANGED) as? Location ?: return

        val p = c.getSharedPreferences("move", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val t = if (loc.time > 0) loc.time else now
        val lastT = p.getLong("t", 0L)
        val lastLat = Double.fromBits(p.getLong("lat", 0L))
        val lastLon = Double.fromBits(p.getLong("lon", 0L))
        var hits = p.getInt("hits", 0)

        if (!TrackingService.recording && lastT > 0L) {
            val dt = (t - lastT) / 1000.0
            if (dt in 20.0..900.0) {
                val res = FloatArray(1)
                Location.distanceBetween(lastLat, lastLon, loc.latitude, loc.longitude, res)
                val v = res[0] / dt
                hits = if (res[0] >= 100f && v >= 1.0) hits + 1 else 0
            } else {
                hits = 0
            }
            val lastNotify = p.getLong("notified", 0L)
            if (hits >= 2 && now - lastNotify > 30 * 60_000L) {
                Notifs.post(
                    c, 5, "🚶 شكلك عم تتحرك",
                    "التسجيل مطفي. اضغط لبدء تسجيل مسارك.", "autostart"
                )
                hits = 0
                p.edit().putLong("notified", now).apply()
            }
        } else {
            hits = 0
        }

        p.edit()
            .putLong("t", t)
            .putLong("lat", loc.latitude.toRawBits())
            .putLong("lon", loc.longitude.toRawBits())
            .putInt("hits", hits)
            .apply()
    }
}
