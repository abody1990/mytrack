package com.mytrack.app

import android.location.Location

/** مكان متكرر: مجموعة زيارات ضمن 100 متر من بعض. */
class Cluster(
    val lat: Double,
    val lon: Double,
    val count: Int,
    val totalMs: Long,
    val name: String?,
    val saved: Boolean,
    val savedId: Long
)

object Places {

    private class Acc(val lat: Double, val lon: Double) {
        var count = 0
        var ms = 0L
        val names = HashMap<String, Int>()
    }

    fun cluster(visits: List<Visit>, saved: List<SavedPlace>): List<Cluster> {
        val accs = ArrayList<Acc>()
        val res = FloatArray(1)
        for (v in visits) {
            var found: Acc? = null
            for (a in accs) {
                Location.distanceBetween(a.lat, a.lon, v.lat, v.lon, res)
                if (res[0] <= 100f) {
                    found = a
                    break
                }
            }
            val acc = found ?: Acc(v.lat, v.lon).also { accs.add(it) }
            acc.count++
            acc.ms += (v.leave - v.arrive)
            v.name?.let { acc.names[it] = (acc.names[it] ?: 0) + 1 }
        }

        val out = ArrayList<Cluster>()
        for (a in accs) {
            var savedName: String? = null
            var savedId = -1L
            for (s in saved) {
                Location.distanceBetween(a.lat, a.lon, s.lat, s.lon, res)
                if (res[0] <= 100f) {
                    savedName = s.name
                    savedId = s.id
                    break
                }
            }
            val best = a.names.entries.maxByOrNull { it.value }?.key
            out.add(Cluster(a.lat, a.lon, a.count, a.ms, savedName ?: best, savedName != null, savedId))
        }
        return out.sortedWith(compareByDescending<Cluster> { it.count }.thenByDescending { it.totalMs })
    }
}
