package com.mytrack.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale

/** رسم بياني بسيط بأعمدة. */
class BarChart(context: Context) : View(context) {
    var values: List<Float> = emptyList()
    var labels: List<String> = emptyList()
    var barColor: Int = Color.parseColor("#1B9E5A")
    var textColor: Int = Color.GRAY

    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val n = values.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val top = 18 * d
        val bottom = 22 * d
        val chartH = h - top - bottom
        val maxV = maxOf(values.maxOrNull() ?: 0f, 0.1f)
        val slot = w / n
        val bw = slot * 0.62f
        val every = if (n > 10) (n + 9) / 10 else 1

        p.textAlign = Paint.Align.CENTER
        p.textSize = 10 * d
        p.style = Paint.Style.FILL

        for (i in 0 until n) {
            val x = slot * i + slot / 2
            var bh = chartH * (values[i] / maxV)
            if (values[i] > 0 && bh < 2 * d) bh = 2 * d
            p.color = barColor
            rect.set(x - bw / 2, top + chartH - bh, x + bw / 2, top + chartH)
            c.drawRoundRect(rect, 4 * d, 4 * d, p)

            p.color = textColor
            if (n <= 8 && values[i] > 0) {
                c.drawText(String.format(Locale.US, "%.1f", values[i]), x, top + chartH - bh - 4 * d, p)
            }
            if (i % every == 0 || i == n - 1) {
                c.drawText(labels.getOrElse(i) { "" }, x, h - 6 * d, p)
            }
        }
        p.color = textColor
        p.strokeWidth = 1 * d
        c.drawLine(0f, top + chartH, w, top + chartH, p)
    }
}
