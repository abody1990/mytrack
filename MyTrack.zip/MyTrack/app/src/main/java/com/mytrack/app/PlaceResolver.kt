package com.mytrack.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * بيعرف اسم المكان من إحداثياته عن طريق Nominatim (خدمة OpenStreetMap).
 * بيحتاج إنترنت؛ إذا ما في، الأماكن بتضل بدون اسم وبنجرّب مرة ثانية لاحقاً.
 */
object PlaceResolver {

    private val running = AtomicBoolean(false)

    private val LABELS = mapOf(
        "hospital" to "مشفى", "clinic" to "عيادة", "doctors" to "عيادة", "pharmacy" to "صيدلية",
        "dentist" to "عيادة أسنان", "school" to "مدرسة", "kindergarten" to "روضة",
        "university" to "جامعة", "college" to "كلية", "place_of_worship" to "دار عبادة",
        "mosque" to "جامع", "church" to "كنيسة", "restaurant" to "مطعم", "cafe" to "مقهى",
        "fast_food" to "وجبات سريعة", "bakery" to "مخبز", "bank" to "مصرف", "atm" to "صراف",
        "marketplace" to "سوق", "supermarket" to "سوبرماركت", "mall" to "مول",
        "fuel" to "محطة وقود", "police" to "شرطة", "townhall" to "بلدية",
        "post_office" to "بريد", "park" to "حديقة", "stadium" to "ملعب", "hotel" to "فندق",
        "bus_station" to "محطة باصات", "station" to "محطة"
    )

    private val POI_KEYS = listOf(
        "hospital", "clinic", "pharmacy", "school", "university", "college", "place_of_worship",
        "restaurant", "cafe", "fast_food", "bank", "marketplace", "supermarket", "mall", "fuel",
        "police", "townhall", "post_office", "hotel", "park", "stadium", "amenity", "shop",
        "tourism", "leisure", "office", "building"
    )

    fun resolvePendingAsync(ctx: Context) {
        if (!running.compareAndSet(false, true)) return
        val app = ctx.applicationContext
        Thread {
            try {
                val db = TrackDb(app)
                for (v in db.pendingVisits()) {
                    val r = lookup(v.lat, v.lon) ?: break // ما في إنترنت: وقّف وجرّب لاحقاً
                    db.setVisitName(v.id, r.first, r.second)
                    Thread.sleep(1100) // سياسة Nominatim: طلب واحد بالثانية على الأكتر
                }
            } catch (_: Throwable) {
            } finally {
                running.set(false)
            }
        }.start()
    }

    private fun lookup(lat: Double, lon: Double): Pair<String, String>? {
        val url = URL(
            "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1" +
                "&accept-language=ar&lat=$lat&lon=$lon"
        )
        val c = url.openConnection() as HttpURLConnection
        try {
            c.setRequestProperty("User-Agent", "MyTrack/1.0 (personal Android app)")
            c.connectTimeout = 10000
            c.readTimeout = 10000
            if (c.responseCode != 200) return null
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            if (j.has("error")) return Pair("مكان غير معروف", "")

            var name = j.optString("name", "")
            var type = LABELS[j.optString("type", "")] ?: ""
            val addr = j.optJSONObject("address")

            if (name.isBlank() && addr != null) {
                for (k in POI_KEYS) {
                    val s = addr.optString(k, "")
                    if (s.isNotBlank() && s != "yes") {
                        name = s
                        if (type.isEmpty()) type = LABELS[k] ?: ""
                        break
                    }
                }
            }
            if (name.isBlank() && addr != null) {
                val road = addr.optString("road", "")
                var area = ""
                for (k in listOf("suburb", "neighbourhood", "city_district", "city", "town", "village")) {
                    val s = addr.optString(k, "")
                    if (s.isNotBlank()) {
                        area = s
                        break
                    }
                }
                name = listOf(road, area).filter { it.isNotBlank() }.joinToString("، ")
            }
            if (name.isBlank()) {
                name = j.optString("display_name", "").split(",").take(2).joinToString("،").trim()
            }
            if (name.isBlank()) name = "مكان غير معروف"
            return Pair(name, type)
        } catch (_: Throwable) {
            return null
        } finally {
            c.disconnect()
        }
    }
}
