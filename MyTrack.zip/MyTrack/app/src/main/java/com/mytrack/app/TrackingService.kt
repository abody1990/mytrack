package com.mytrack.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.osmdroid.util.GeoPoint
import java.util.concurrent.CopyOnWriteArrayList

/**
 * خدمة تسجيل المسار. بتستخدم GPS الجهاز مباشرة (ما بتحتاج إنترنت)،
 * بتحفظ كل نقطة بقاعدة البيانات، وبتكتشف الأماكن اللي بتوقف فيها،
 * وبتوقف لحالها إذا بقيت ثابت، وبتخفف الدقة إذا البطارية ضعيفة.
 */
class TrackingService : Service(), LocationListener {

    companion object {
        const val ACTION_STOP = "com.mytrack.app.STOP"
        private const val DWELL_RADIUS = 70f                 // متر
        private const val DWELL_MIN_MS = 5 * 60 * 1000L      // 5 دقايق
        private const val STILL_RADIUS = 40f                 // متر، للإيقاف التلقائي

        @Volatile var recording = false
        @Volatile var autoStarted = false
        @Volatile var tripId: Long = -1
        @Volatile var distance = 0f
        @Volatile var speedKmh = 0f
        @Volatile var lastFixAt = 0L
        @Volatile var startedAt = 0L
        @Volatile var onUpdate: (() -> Unit)? = null
        val live = CopyOnWriteArrayList<GeoPoint>()
    }

    private lateinit var lm: LocationManager
    private lateinit var db: TrackDb
    private var last: Location? = null

    // كشف التوقف (الأماكن)
    private var anchor: Location? = null   // أول نقطة بالمكان
    private var lastIn: Location? = null   // آخر نقطة ضمن نفس المكان
    private var visitId = -1L

    // الإيقاف التلقائي والبطارية
    private var stillAnchor: Location? = null
    private var lastMoveAt = 0L
    private var lowPower = false

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!recording) return
            periodic()
            if (recording) handler.postDelayed(this, 30_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        db = TrackDb(this)
    }

    @SuppressLint("MissingPermission")
    private fun requestUpdates(low: Boolean) {
        try {
            lm.removeUpdates(this)
        } catch (_: SecurityException) {
        }
        if (low) {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000L, 10f, this)
        } else {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 3f, this)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            return START_NOT_STICKY
        }

        try {
            ServiceCompat.startForeground(
                this, 1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (_: Throwable) {
            Notifs.post(this, 4, "ما قدرت أبدأ التسجيل", "اضغط لفتح التطبيق وابدأ التسجيل يدوياً", "autostart")
            stopSelf()
            return START_NOT_STICKY
        }

        if (!recording) {
            // intent == null يعني النظام رجّع الخدمة بعد ما قتلها: كمّل الرحلة المفتوحة
            val id = if (intent == null) (db.openTrip() ?: -1L) else db.startTrip()
            if (id < 0) {
                stopTracking()
                return START_NOT_STICKY
            }
            tripId = id
            autoStarted = intent?.getBooleanExtra("auto", false) == true
            startedAt = db.tripStart(id)
            live.clear()
            distance = 0f
            speedKmh = 0f
            var prev: GeoPoint? = null
            for (p in db.points(id)) {
                val g = GeoPoint(p.lat, p.lon)
                prev?.let { distance += it.distanceToAsDouble(g).toFloat() }
                prev = g
                live.add(g)
            }
            last = null
            anchor = null
            lastIn = null
            visitId = -1L
            stillAnchor = null
            lastMoveAt = System.currentTimeMillis()
            lowPower = false
            recording = true
            try {
                requestUpdates(false)
            } catch (e: SecurityException) {
                stopTracking()
                return START_NOT_STICKY
            }
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, 30_000L)
            TrackWidget.update(this)
        }
        onUpdate?.invoke()
        return START_STICKY
    }

    override fun onLocationChanged(l: Location) {
        if (!recording || tripId < 0) return
        if (l.hasAccuracy() && l.accuracy > 50f) return // تجاهل القراءات الضعيفة

        val prev = last
        val spd: Double = if (l.hasSpeed()) {
            l.speed.toDouble()
        } else if (prev != null && l.time > prev.time) {
            prev.distanceTo(l).toDouble() / ((l.time - prev.time) / 1000.0)
        } else {
            0.0
        }
        speedKmh = (spd * 3.6).toFloat()
        lastFixAt = System.currentTimeMillis()

        // للإيقاف التلقائي: آخر مرة تحركت فيها أكتر من 40م
        val sa = stillAnchor
        if (sa == null || sa.distanceTo(l) > STILL_RADIUS) {
            stillAnchor = l
            lastMoveAt = System.currentTimeMillis()
        }

        if (prev != null) distance += prev.distanceTo(l)
        last = l
        db.addPoint(tripId, l.latitude, l.longitude, if (l.hasAltitude()) l.altitude else 0.0, l.time, spd)
        live.add(GeoPoint(l.latitude, l.longitude))
        trackDwell(l)
        onUpdate?.invoke()
    }

    /** بيتنفذ كل 30 ثانية: إيقاف تلقائي، توفير بطارية، تحديث الويدجت. */
    private fun periodic() {
        val limit = Prefs.autoStopMin(this)
        if (limit > 0 && System.currentTimeMillis() - lastMoveAt >= limit * 60_000L) {
            Notifs.post(
                this, 6, "⏹ وقّفت التسجيل تلقائياً",
                "ما تحركت من حوالي $limit دقيقة. اضغط لعرض التقرير.", "report"
            )
            stopTracking()
            return
        }

        if (Prefs.lowBattery(this)) {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
            try {
                if (!lowPower && pct <= 15 && !charging) {
                    lowPower = true
                    requestUpdates(true)
                    Notifs.post(
                        this, 7, "🔋 البطارية ضعيفة ($pct%)",
                        "خفّضت دقة التسجيل لتوفير البطارية. التسجيل مكمّل.", "none"
                    )
                } else if (lowPower && (pct >= 25 || charging)) {
                    lowPower = false
                    requestUpdates(false)
                }
            } catch (_: SecurityException) {
            }
        }
        TrackWidget.update(this)
    }

    /**
     * إذا بقيت ضمن نطاق 70م لمدة 5 دقايق أو أكتر، بنحفظها كمكان زرته.
     * وإذا انقطع الـ GPS جوّا مبنى وبعدين رجع من نفس المكان، بتنحسب كزيارة كمان.
     */
    private fun trackDwell(l: Location) {
        val a = anchor
        if (a == null) {
            anchor = l
            lastIn = l
            visitId = -1L
            return
        }
        if (a.distanceTo(l) <= DWELL_RADIUS) {
            if (visitId >= 0) {
                db.updateVisitLeave(visitId, l.time)
            } else if (l.time - a.time >= DWELL_MIN_MS) {
                visitId = db.addVisit(tripId, a.latitude, a.longitude, a.time, l.time)
                PlaceResolver.resolvePendingAsync(applicationContext)
            }
            lastIn = l
        } else {
            if (visitId < 0) {
                val li = lastIn ?: a
                val slow = !li.hasSpeed() || li.speed < 2f
                if (l.time - a.time >= DWELL_MIN_MS && slow) {
                    db.addVisit(tripId, a.latitude, a.longitude, a.time, l.time)
                    PlaceResolver.resolvePendingAsync(applicationContext)
                }
            }
            anchor = l
            lastIn = l
            visitId = -1L
        }
    }

    private fun stopTracking() {
        handler.removeCallbacks(tick)
        try { lm.removeUpdates(this) } catch (_: SecurityException) {}
        val a = anchor
        if (tripId >= 0) {
            // وقفت التسجيل وانت واقف بمكان من فترة
            val now = System.currentTimeMillis()
            if (a != null && visitId < 0 && now - a.time >= DWELL_MIN_MS) {
                val li = lastIn ?: a
                if (!li.hasSpeed() || li.speed < 2f) {
                    db.addVisit(tripId, a.latitude, a.longitude, a.time, now)
                }
            }
            db.endTrip(tripId)
            PlaceResolver.resolvePendingAsync(applicationContext)
        }
        recording = false
        autoStarted = false
        tripId = -1
        last = null
        anchor = null
        lastIn = null
        visitId = -1L
        stillAnchor = null
        speedKmh = 0f
        onUpdate?.invoke()
        TrackWidget.update(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { lm.removeUpdates(this) } catch (_: SecurityException) {}
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        Notifs.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Notifs.CH_REC)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("مساري")
            .setContentText("جاري تسجيل مسارك…")
            .setContentIntent(open)
            .addAction(0, "إيقاف", stop)
            .setOngoing(true)
            .build()
    }
}
