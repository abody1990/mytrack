package com.mytrack.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.osmdroid.util.GeoPoint
import java.util.concurrent.CopyOnWriteArrayList

/**
 * خدمة تسجيل المسار. بتستخدم GPS الجهاز مباشرة (ما بتحتاج إنترنت)
 * وبتحفظ كل نقطة بقاعدة البيانات أول بأول.
 */
class TrackingService : Service(), LocationListener {

    companion object {
        const val ACTION_STOP = "com.mytrack.app.STOP"
        private const val CHANNEL = "tracking"

        @Volatile var recording = false
        @Volatile var tripId: Long = -1
        @Volatile var distance = 0f
        @Volatile var onUpdate: (() -> Unit)? = null
        val live = CopyOnWriteArrayList<GeoPoint>()
    }

    private lateinit var lm: LocationManager
    private lateinit var db: TrackDb
    private var last: Location? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        db = TrackDb(this)
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(
            this, 1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        )

        if (!recording) {
            // intent == null يعني النظام رجّع الخدمة بعد ما قتلها: كمّل الرحلة المفتوحة
            val id = if (intent == null) (db.openTrip() ?: -1L) else db.startTrip()
            if (id < 0) {
                stopTracking()
                return START_NOT_STICKY
            }
            tripId = id
            live.clear()
            distance = 0f
            var prev: GeoPoint? = null
            for (p in db.points(id)) {
                val g = GeoPoint(p.lat, p.lon)
                prev?.let { distance += it.distanceToAsDouble(g).toFloat() }
                prev = g
                live.add(g)
            }
            last = null
            recording = true
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 3f, this)
            } catch (e: SecurityException) {
                stopTracking()
                return START_NOT_STICKY
            }
        }
        onUpdate?.invoke()
        return START_STICKY
    }

    override fun onLocationChanged(l: Location) {
        if (!recording || tripId < 0) return
        if (l.hasAccuracy() && l.accuracy > 50f) return // تجاهل القراءات الضعيفة
        last?.let { distance += it.distanceTo(l) }
        last = l
        db.addPoint(tripId, l.latitude, l.longitude, if (l.hasAltitude()) l.altitude else 0.0, l.time)
        live.add(GeoPoint(l.latitude, l.longitude))
        onUpdate?.invoke()
    }

    private fun stopTracking() {
        try { lm.removeUpdates(this) } catch (_: SecurityException) {}
        if (tripId >= 0) db.endTrip(tripId)
        recording = false
        tripId = -1
        last = null
        onUpdate?.invoke()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { lm.removeUpdates(this) } catch (_: SecurityException) {}
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "تسجيل المسار", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("مساري")
            .setContentText("جاري تسجيل مسارك…")
            .setContentIntent(open)
            .addAction(0, "إيقاف", stop)
            .setOngoing(true)
            .build()
    }
}
