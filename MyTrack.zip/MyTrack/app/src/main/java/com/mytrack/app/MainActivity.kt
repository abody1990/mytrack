package com.mytrack.app

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.location.LocationManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يرسم موقعك على الخريطة: صورتك (دائرية) إذا اخترتها، أو نقطة زرقا. */
class MeOverlay(context: Context) : Overlay() {
    var location: GeoPoint? = null
    var avatar: Bitmap? = null
    private val pt = Point()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = context.resources.displayMetrics.density

    override fun draw(c: Canvas, osmv: MapView, shadow: Boolean) {
        if (shadow) return
        val loc = location ?: return
        osmv.projection.toPixels(loc, pt)
        val x = pt.x.toFloat()
        val y = pt.y.toFloat()
        val a = avatar
        if (a != null) {
            c.drawBitmap(a, x - a.width / 2f, y - a.height / 2f, null)
        } else {
            val r = 9 * d
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#332563EB")
            c.drawCircle(x, y, r * 2.4f, paint)
            paint.color = Color.WHITE
            c.drawCircle(x, y, r * 1.3f, paint)
            paint.color = Color.parseColor("#2563EB")
            c.drawCircle(x, y, r, paint)
        }
    }
}

class MainActivity : AppCompatActivity() {

    private companion object {
        val GREEN = Color.parseColor("#1B9E5A")
        val RED = Color.parseColor("#D93636")
        val ORANGE = Color.parseColor("#F59E0B")
        val FAST = Color.parseColor("#DC2626")
    }

    // ألوان حسب المظهر (فاتح/داكن)
    private var dark = false
    private val ink get() = if (dark) Color.parseColor("#E5E7EB") else Color.parseColor("#1F2937")
    private val muted get() = if (dark) Color.parseColor("#9CA3AF") else Color.parseColor("#6B7280")
    private val tileBg get() = if (dark) Color.parseColor("#2A3140") else Color.parseColor("#F1F5F9")
    private val panelBg get() = if (dark) Color.parseColor("#161B26") else Color.WHITE
    private val ripple get() = if (dark) 0x33FFFFFF else 0x22000000

    private lateinit var map: MapView
    private lateinit var db: TrackDb
    private lateinit var provider: GpsMyLocationProvider
    private lateinit var meOverlay: MeOverlay
    private lateinit var btnRec: Button
    private lateinit var status: TextView
    private lateinit var sub: TextView
    private lateinit var vSpeed: TextView
    private lateinit var vDist: TextView
    private lateinit var vTime: TextView

    private var liveLine: Polyline? = null
    private val shownLines = ArrayList<Polyline>()
    private var visitMarker: Marker? = null
    private var follow = true
    private var myLoc: GeoPoint? = null
    private var centered = false
    private var todayStats: DayStats? = null
    private var wasRecording = false

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshText()
            handler.postDelayed(this, 1000)
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) saveAvatar(uri)
    }

    private val pickBackup = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) restoreFrom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        dark = Prefs.isDark(this)
        setTheme(if (dark) R.style.AppDark else R.style.AppLight)
        super.onCreate(savedInstanceState)

        // سجّل أي انهيار بملف عشان نعرض سببه بالفتحة الجاية
        val crashFile = File(filesDir, "crash.txt")
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { crashFile.writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        // كل شي (الخرائط المخزّنة) بمجلد التطبيق، ما بنحتاج صلاحية تخزين
        val base = File(getExternalFilesDir(null), "osmdroid")
        File(base, "tiles").mkdirs()
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = base
            osmdroidTileCache = File(base, "tiles")
            tileFileSystemCacheMaxBytes = 2L * 1024 * 1024 * 1024
            tileFileSystemCacheTrimBytes = 1500L * 1024 * 1024
            setExpirationOverrideDuration(30L * 24 * 3600 * 1000)
        }

        db = TrackDb(this)
        provider = GpsMyLocationProvider(this)
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            controller.setZoom(15.0)
            controller.setCenter(GeoPoint(33.5138, 36.2765))
            setUseDataConnection(!prefs.getBoolean("offline", false))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_MOVE) follow = false
                false
            }
        }
        if (dark) map.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
        meOverlay = MeOverlay(this)
        loadAvatar()
        map.overlays.add(meOverlay)

        // ----- الواجهة -----
        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(panelBg)
                val r = dp(24).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            elevation = dp(10).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }

        status = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        sub = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(2), 0, dp(6))
        }

        vSpeed = TextView(this)
        vDist = TextView(this)
        vTime = TextView(this)
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(10))
        }
        statsRow.addView(cell(vSpeed, "كم/س"))
        statsRow.addView(cell(vDist, "كم"))
        statsRow.addView(cell(vTime, "المدة"))

        btnRec = Button(this).apply {
            isAllCaps = false
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            stateListAnimator = null
            setOnClickListener { toggleRecording() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(54))
        }

        val row1 = rowOf(
            tile("📂", "رحلاتي") { showTrips() },
            tile("📊", "التقرير") { showReport(System.currentTimeMillis()) },
            tile("📌", "أماكني") { showPlaces() },
            tile("📍", "موقعي") { goToMe() }
        )
        row1.setPadding(0, dp(12), 0, 0)

        val more = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        more.addView(
            rowOf(
                tile("⏰", "جدولة") { scheduleDialog() },
                tile("📈", "إحصائيات") { showStats() },
                tile("🖼", "صورتي") { avatarMenu() },
                tile("🗺", "بدون نت") { showOfflineHelp() }
            )
        )
        more.addView(
            rowOf(
                tile("⚙", "إعدادات") { settingsDialog() },
                tile("💾", "نسخ احتياطي") { exportBackup() },
                tile("📥", "استعادة") { pickBackup.launch("*/*") }
            )
        )
        val toggle = TextView(this).apply {
            text = "⋯ المزيد"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(2))
            setOnClickListener {
                val show = more.visibility != View.VISIBLE
                more.visibility = if (show) View.VISIBLE else View.GONE
                text = if (show) "▲ أقل" else "⋯ المزيد"
            }
        }

        panel.addView(status)
        panel.addView(sub)
        panel.addView(statsRow)
        panel.addView(btnRec)
        panel.addView(row1)
        panel.addView(toggle)
        panel.addView(more)

        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        if (crashFile.exists()) {
            val text = try { crashFile.readText().take(1500) } catch (_: Throwable) { "" }
            crashFile.delete()
            AlertDialog.Builder(this)
                .setTitle("التطبيق سكّر المرة الماضية")
                .setMessage(text)
                .setPositiveButton("تمام", null)
                .show()
        } else if (!hasLocation()) {
            askPermissions()
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.getBooleanExtra("report", false)) {
            i.removeExtra("report")
            showReport(System.currentTimeMillis())
        }
        if (i.getBooleanExtra("autostart", false)) {
            i.removeExtra("autostart")
            if (!TrackingService.recording) toggleRecording()
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        startLocation()
        if (Schedule.enabled(this)) Schedule.scheduleAll(this)
        Reminder.sync(this)
        TrackWidget.update(this)
        TrackingService.onUpdate = { updateUi() }
        updateUi()
        computeToday()
        PlaceResolver.resolvePendingAsync(this)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        TrackingService.onUpdate = null
        provider.stopLocationProvider()
        map.onPause()
    }

    // ---------------- الموقع الحالي ----------------

    private fun startLocation() {
        if (!hasLocation()) return
        try {
            provider.startLocationProvider(IMyLocationConsumer { l, _ ->
                if (l != null) onMyLocation(GeoPoint(l.latitude, l.longitude))
            })
            provider.lastKnownLocation?.let { onMyLocation(GeoPoint(it.latitude, it.longitude)) }
        } catch (_: SecurityException) {
        }
    }

    private fun onMyLocation(g: GeoPoint) {
        myLoc = g
        meOverlay.location = g
        if (!centered) {
            centered = true
            map.controller.setZoom(17.0)
            map.controller.setCenter(g)
        }
        map.postInvalidate()
    }

    private fun goToMe() {
        follow = true
        val loc = myLoc
        if (loc != null) {
            map.controller.animateTo(loc)
            map.controller.setZoom(17.0)
        } else {
            toast("لسا ما التقط الـ GPS موقعك، انتظر شوي")
        }
    }

    // ---------------- صورتك على الخريطة ----------------

    private fun avatarFile() = File(filesDir, "avatar.png")

    private fun avatarMenu() {
        val has = avatarFile().exists()
        val items = if (has) arrayOf("اختيار صورة جديدة", "إزالة الصورة") else arrayOf("اختيار صورة من المعرض")
        AlertDialog.Builder(this)
            .setTitle("صورتك على الخريطة")
            .setItems(items) { _, i ->
                if (i == 0) pickImage.launch("image/*") else removeAvatar()
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun loadAvatar() {
        val f = avatarFile()
        meOverlay.avatar = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun removeAvatar() {
        avatarFile().delete()
        meOverlay.avatar = null
        map.invalidate()
        toast("رجعت العلامة الزرقا")
    }

    private fun saveAvatar(uri: Uri) {
        try {
            val src = loadBitmap(uri)
            if (src == null) {
                toast("ما قدرت أفتح الصورة")
                return
            }
            val out = makeAvatar(src, dp(56))
            avatarFile().outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            meOverlay.avatar = out
            map.invalidate()
            toast("تم! صورتك صارت على الخريطة")
        } catch (t: Throwable) {
            toast("خطأ: ${t.javaClass.simpleName}")
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (_: Throwable) {
            1
        }
        val deg = when (orientation) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    /** يقصّ الصورة مربع من النص ويحوّلها لدائرة بإطار أبيض. */
    private fun makeAvatar(src: Bitmap, size: Int): Bitmap {
        val border = maxOf(3, size / 14)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = size / 2f
        p.color = Color.WHITE
        c.drawCircle(r, r, r, p)

        val s = minOf(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        val inner = size - border * 2
        val scaled = Bitmap.createScaledBitmap(square, inner, inner, true)
        val shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        shader.setLocalMatrix(Matrix().apply { setTranslate(border.toFloat(), border.toFloat()) })
        p.shader = shader
        c.drawCircle(r, r, r - border, p)
        return out
    }

    // ---------------- التسجيل ----------------

    private fun toggleRecording() {
        if (TrackingService.recording) {
            startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
            return
        }
        if (!hasLocation()) {
            askPermissions()
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            toast("فعّل الـ GPS من الإعدادات")
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        follow = true
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
    }

    /** يحدّث الخريطة وزر التسجيل (بيتنفذ كل ما توصل نقطة جديدة). */
    private fun updateUi() {
        val rec = TrackingService.recording
        btnRec.text = if (rec) "⏹  إيقاف التسجيل" else "⏺  ابدأ التسجيل"
        btnRec.background = pressable(if (rec) RED else GREEN, 16, 0x33FFFFFF)

        val pts = TrackingService.live.toList()
        if (rec || pts.isNotEmpty()) {
            val line = liveLine ?: Polyline(map).also {
                it.outlinePaint.color = Color.RED
                it.outlinePaint.strokeWidth = 10f
                map.overlays.add(it)
                liveLine = it
            }
            line.setPoints(pts)
        }
        if (rec && follow && pts.isNotEmpty()) map.controller.animateTo(pts.last())
        if (wasRecording && !rec) computeToday()
        wasRecording = rec
        refreshText()
        map.invalidate()
    }

    /** يحدّث الأرقام (السرعة/المسافة/المدة)، بيتنفذ كل ثانية. */
    private fun refreshText() {
        if (TrackingService.recording) {
            val fresh = System.currentTimeMillis() - TrackingService.lastFixAt < 10_000
            val kmh = if (fresh) TrackingService.speedKmh else 0f
            vSpeed.text = String.format(Locale.US, "%.1f", kmh)
            vDist.text = String.format(Locale.US, "%.2f", TrackingService.distance / 1000f)
            vTime.text = Report.clock((System.currentTimeMillis() - TrackingService.startedAt) / 1000)
            status.text = if (TrackingService.autoStarted) "🔴 جاري التسجيل (مجدول)" else "🔴 جاري التسجيل"
            sub.text = "${TrackingService.live.size} نقطة"
        } else {
            val s = todayStats
            vSpeed.text = "—"
            vDist.text = if (s != null) Report.km(s.meters) else "—"
            vTime.text = if (s != null) Report.clock(s.seconds) else "—"
            status.text = if (TrackingService.live.isNotEmpty()) "✔ تم حفظ الرحلة" else "جاهز للتسجيل"
            sub.text = "المسافة والمدة هون: إجمالي اليوم"
        }
    }

    private fun computeToday() {
        Thread {
            val (from, to) = Report.dayBounds(System.currentTimeMillis())
            val s = try { Report.stats(db, from, to) } catch (_: Throwable) { null }
            runOnUiThread {
                todayStats = s
                refreshText()
            }
        }.start()
    }

    // ---------------- التقرير اليومي ----------------

    private fun showReport(ref: Long) {
        val (from, to) = Report.dayBounds(ref)
        val body = Report.text(Report.stats(db, from, to), from)
        val tv = TextView(this).apply {
            text = body
            textSize = 15f
            setTextColor(ink)
            setLineSpacing(0f, 1.25f)
            setPadding(dp(22), dp(14), dp(22), dp(8))
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        val b = AlertDialog.Builder(this)
            .setTitle("📊 التقرير اليومي")
            .setView(sv)
            .setPositiveButton("مشاركة") { _, _ -> shareText(body) }
            .setNeutralButton("◀ اليوم السابق") { _, _ -> showReport(from - 3600_000L) }
        if (to <= System.currentTimeMillis()) {
            b.setNegativeButton("اليوم التالي ▶") { _, _ -> showReport(to + 3600_000L) }
        } else {
            b.setNegativeButton("إغلاق", null)
        }
        b.show()
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "مشاركة التقرير"))
    }

    // ---------------- الإحصائيات (أسبوعي / شهري) ----------------

    private fun showStats() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), 0)
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b7 = chip("آخر 7 أيام")
        val b30 = chip("آخر 30 يوم")
        tabs.addView(b7)
        tabs.addView(b30)
        val summary = TextView(this).apply {
            textSize = 14f
            setTextColor(ink)
            setLineSpacing(0f, 1.2f)
            setPadding(0, dp(10), 0, dp(6))
        }
        val chart = BarChart(this).apply {
            barColor = GREEN
            textColor = muted
        }
        box.addView(tabs)
        box.addView(summary)
        box.addView(chart, LinearLayout.LayoutParams(-1, dp(190)))

        val dialog = AlertDialog.Builder(this)
            .setTitle("📈 إحصائياتي")
            .setView(box)
            .setPositiveButton("إغلاق", null)
            .create()

        fun load(days: Int) {
            summary.text = "جاري الحساب…"
            Thread {
                val data = try { Report.daily(db, days) } catch (_: Throwable) { emptyList() }
                runOnUiThread {
                    if (!dialog.isShowing) return@runOnUiThread
                    val labelFmt = SimpleDateFormat(
                        if (days <= 7) "EEE" else "d",
                        if (days <= 7) Locale.forLanguageTag("ar") else Locale.US
                    )
                    chart.values = data.map { (it.second.meters / 1000).toFloat() }
                    chart.labels = data.map { labelFmt.format(Date(it.first)) }
                    chart.invalidate()

                    val total = data.sumOf { it.second.meters }
                    val active = data.count { it.second.meters > 0 }
                    val secs = data.sumOf { it.second.seconds }
                    val walk = data.sumOf { it.second.walkM }
                    val bike = data.sumOf { it.second.bikeM }
                    val car = data.sumOf { it.second.carM }
                    val best = data.maxByOrNull { it.second.meters }
                    val sb = StringBuilder()
                    sb.append("📏 المجموع: ${Report.km(total)} كم  •  ⏱ ${Report.dur(secs)}\n")
                    if (active > 0) {
                        sb.append("📅 أيام فيها تسجيل: $active  •  المعدل ${Report.km(total / active)} كم/يوم\n")
                        if (best != null && best.second.meters > 0) {
                            val f = SimpleDateFormat("EEEE d/M", Locale.forLanguageTag("ar"))
                            sb.append("🏆 أكتر يوم: ${f.format(Date(best.first))} (${Report.km(best.second.meters)} كم)\n")
                        }
                        sb.append("🚶 ${Report.km(walk)}   🚴 ${Report.km(bike)}   🚗 ${Report.km(car)} كم")
                    } else {
                        sb.append("ما في رحلات بهالفترة.")
                    }
                    summary.text = sb.toString()
                }
            }.start()
        }

        b7.setOnClickListener { load(7) }
        b30.setOnClickListener { load(30) }
        dialog.show()
        load(7)
    }

    // ---------------- الأماكن ----------------

    private fun showPlaces() {
        PlaceResolver.resolvePendingAsync(this)
        val list = db.recentVisits(40)
        if (list.isEmpty()) {
            toast("ما في أماكن لسا. التطبيق بيحفظ أي مكان بتوقف فيه 5 دقايق أو أكتر وهو بيسجّل")
            return
        }
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.US)
        val labels = list.map { v ->
            "${Report.placeLabel(v)}\n${fmt.format(Date(v.arrive))}  •  ${Report.dur((v.leave - v.arrive) / 1000)}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("📌 أماكني")
            .setItems(labels) { _, i -> placeActions(list[i]) }
            .setPositiveButton("⭐ الأكثر زيارة") { _, _ -> showFrequent() }
            .setNeutralButton("تحديث الأسماء") { _, _ ->
                PlaceResolver.resolvePendingAsync(this)
                toast("جاري معرفة الأسماء (بدها إنترنت)")
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun placeActions(v: Visit) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("عرض على الخريطة", "تعديل الاسم", "تثبيت كمكان ثابت (البيت/الشغل…)", "حذف")) { _, i ->
                when (i) {
                    0 -> showVisit(v)
                    1 -> renameVisit(v)
                    2 -> saveFixed(v.lat, v.lon, v.name)
                    3 -> {
                        db.deleteVisit(v.id)
                        toast("انحذف")
                    }
                }
            }
            .show()
    }

    private fun showFrequent() {
        val cl = Places.cluster(db.allVisits(), db.savedPlaces())
        if (cl.isEmpty()) {
            toast("ما في أماكن لسا")
            return
        }
        val shown = cl.take(60)
        val labels = shown.map { c ->
            "${if (c.saved) "⭐ " else ""}${c.name ?: "مكان بدون اسم"}\n" +
                "${c.count} زيارة  •  ${Report.dur(c.totalMs / 1000)}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("⭐ الأكثر زيارة")
            .setItems(labels) { _, i -> clusterActions(shown[i]) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun clusterActions(c: Cluster) {
        val items = if (c.savedId >= 0)
            arrayOf("عرض على الخريطة", "إعادة تسمية المكان الثابت", "إزالة التثبيت")
        else
            arrayOf("عرض على الخريطة", "تثبيت كمكان ثابت (البيت/الشغل…)")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showVisit(Visit(0, 0, c.lat, c.lon, 0, 0, c.name, null))
                    1 -> {
                        if (c.savedId >= 0) db.deleteSavedPlace(c.savedId)
                        saveFixed(c.lat, c.lon, c.name)
                    }
                    2 -> {
                        db.deleteSavedPlace(c.savedId)
                        toast("انشال التثبيت")
                    }
                }
            }
            .show()
    }

    private fun saveFixed(lat: Double, lon: Double, current: String?) {
        val et = EditText(this).apply {
            setText(current ?: "")
            hint = "مثلاً: البيت، الشغل، بيت أهلي"
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("اسم المكان الثابت")
            .setMessage("كل زياراتك الحالية والجاية القريبة من هون (100م) رح تنسمّى بهالاسم.")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    db.addSavedPlace(n, lat, lon)
                    db.applySavedToVisits(lat, lon, n)
                    toast("تم تثبيت: $n")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showVisit(v: Visit) {
        visitMarker?.let { map.overlays.remove(it) }
        val m = Marker(map)
        m.position = GeoPoint(v.lat, v.lon)
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        m.title = v.name ?: "مكان"
        visitMarker = m
        map.overlays.add(m)
        follow = false
        map.controller.animateTo(m.position)
        map.controller.setZoom(18.0)
        m.showInfoWindow()
        map.invalidate()
    }

    private fun renameVisit(v: Visit) {
        val et = EditText(this).apply {
            setText(v.name ?: "")
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("اسم المكان")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    db.setVisitName(v.id, n, v.type ?: "")
                    toast("تم")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- الجدولة ----------------

    private fun scheduleDialog() {
        var s = Schedule.startMin(this)
        var e = Schedule.endMin(this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val sw = Switch(this).apply {
            text = "تشغيل التسجيل تلقائياً كل يوم"
            textSize = 15f
            setTextColor(ink)
            isChecked = Schedule.enabled(this@MainActivity)
        }
        val bs = timeButton()
        val be = timeButton()
        fun refresh() {
            bs.text = "من الساعة  ${Schedule.fmt(s)}"
            be.text = "إلى الساعة  ${Schedule.fmt(e)}"
        }
        refresh()
        bs.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> s = h * 60 + m; refresh() }, s / 60, s % 60, true).show()
        }
        be.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> e = h * 60 + m; refresh() }, e / 60, e % 60, true).show()
        }
        val note = TextView(this).apply {
            text = "• بيبدأ ويوقف لحاله بهالأوقات.\n" +
                "• بيطلعلك إشعار بالتقرير اليومي وقت النهاية.\n" +
                "• اللي بتبدأه انت بإيدك ما بيوقفه الجدول.\n" +
                "• لازم تعطي التطبيق صلاحية الموقع «طوال الوقت» وتخلّي البطارية «غير مقيّدة»."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(10), 0, 0)
        }
        box.addView(sw)
        box.addView(bs)
        box.addView(be)
        box.addView(note)

        AlertDialog.Builder(this)
            .setTitle("⏰ التسجيل المجدول")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                Schedule.save(this, sw.isChecked, s, e)
                if (sw.isChecked) {
                    Schedule.scheduleAll(this)
                    toast("تم. التسجيل رح يشتغل من ${Schedule.fmt(s)} لـ ${Schedule.fmt(e)}")
                    ensureBackgroundAccess()
                } else {
                    Schedule.cancelAll(this)
                    toast("انلغت الجدولة")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun timeButton() = Button(this).apply {
        isAllCaps = false
        textSize = 16f
        setTextColor(ink)
        background = pressable(tileBg, 12, ripple)
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    private fun chip(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(ink)
        background = pressable(tileBg, 12, ripple)
        layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    private fun ensureBackgroundAccess() {
        if (Build.VERSION.SDK_INT < 29) return
        val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (ok) return
        AlertDialog.Builder(this)
            .setTitle("خطوة مهمة")
            .setMessage(
                "عشان هالميزة تشتغل والشاشة مطفية:\n\n" +
                    "1) افتح إعدادات التطبيق ← الأذونات ← الموقع ← «السماح طوال الوقت».\n" +
                    "2) من البطارية اختار «غير مقيّد».\n\n" +
                    "بدون هاد، أندرويد ممكن يمنع التشغيل التلقائي والتنبيهات."
            )
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("لاحقاً", null)
            .show()
    }

    // ---------------- الإعدادات ----------------

    private fun settingsDialog() {
        val themeName = arrayOf("تلقائي (حسب الجهاز)", "فاتح", "داكن")[Prefs.theme(this)]
        val stop = Prefs.autoStopMin(this)
        val stopName = if (stop == 0) "معطّل" else "بعد $stop دقيقة ثبات"
        val on = "مفعّل"
        val off = "معطّل"
        val items = arrayOf(
            "🌓 المظهر: $themeName",
            "⏹ إيقاف تلقائي عند الثبات: $stopName",
            "🔔 تنبيه «نسيت تبدأ التسجيل»: ${if (Prefs.reminder(this)) on else off}",
            "🔋 توفير الدقة عند بطارية ضعيفة: ${if (Prefs.lowBattery(this)) on else off}"
        )
        AlertDialog.Builder(this)
            .setTitle("⚙ الإعدادات")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> {
                        Prefs.setTheme(this, (Prefs.theme(this) + 1) % 3)
                        recreate()
                    }
                    1 -> {
                        val opts = intArrayOf(0, 30, 60, 120)
                        val idx = opts.indexOf(stop)
                        Prefs.setAutoStop(this, opts[(idx + 1) % opts.size])
                        settingsDialog()
                    }
                    2 -> {
                        val enable = !Prefs.reminder(this)
                        Prefs.setReminder(this, enable)
                        Reminder.sync(this)
                        if (enable) ensureBackgroundAccess()
                        settingsDialog()
                    }
                    3 -> {
                        Prefs.setLowBattery(this, !Prefs.lowBattery(this))
                        settingsDialog()
                    }
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    // ---------------- النسخ الاحتياطي ----------------

    private fun exportBackup() {
        toast("جاري تحضير النسخة…")
        Thread {
            try {
                val dir = File(cacheDir, "backup").apply { mkdirs() }
                val name = "mytrack_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".json"
                val f = File(dir, name)
                Backup.write(db, f)
                runOnUiThread {
                    val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "احفظ النسخة (مثلاً على Drive أو أرسلها لنفسك)"))
                }
            } catch (t: Throwable) {
                runOnUiThread { toast("فشل النسخ: ${t.javaClass.simpleName}") }
            }
        }.start()
    }

    private fun restoreFrom(uri: Uri) {
        toast("جاري الاستعادة…")
        Thread {
            try {
                val n = contentResolver.openInputStream(uri)?.use { Backup.restore(db, it) } ?: -1
                runOnUiThread {
                    if (n < 0) toast("ما قدرت أفتح الملف")
                    else toast("تمت الاستعادة: $n رحلة جديدة")
                    computeToday()
                }
            } catch (t: Throwable) {
                runOnUiThread { toast("الملف مو نسخة صالحة: ${t.javaClass.simpleName}") }
            }
        }.start()
    }

    // ---------------- الرحلات ----------------

    private fun showTrips() {
        val trips = db.trips()
        if (trips.isEmpty()) {
            toast("ما في رحلات محفوظة")
            return
        }
        val shown = trips.take(80)
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        val labels = shown.map { t ->
            val a = Report.analyze(db.points(t.id))
            "${Report.typeEmoji(a)} ${fmt.format(Date(t.start))}  •  ${Report.km(a.meters)} كم".trim()
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("رحلاتي")
            .setItems(labels) { _, i -> tripActions(shown[i]) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun tripActions(t: Trip) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("عرض على الخريطة (ملوّن بالسرعة)", "تصدير GPX (مشاركة)", "حذف")) { _, i ->
                when (i) {
                    0 -> showTrip(t)
                    1 -> exportTrip(t)
                    2 -> deleteTrip(t)
                }
            }
            .show()
    }

    private fun clearShownTrip() {
        for (l in shownLines) map.overlays.remove(l)
        shownLines.clear()
    }

    /** يعرض الرحلة ملوّنة: أخضر مشي، برتقالي دراجة/جري، أحمر مركبة. */
    private fun showTrip(t: Trip) {
        val pts = db.points(t.id)
        if (pts.size < 2) {
            toast("الرحلة قصيرة جداً")
            return
        }
        clearShownTrip()
        val sp = Report.segSpeeds(pts)
        fun bucket(v: Double) = if (v <= Report.WALK_MAX) 0 else if (v <= Report.BIKE_MAX) 1 else 2
        fun colorOf(b: Int) = when (b) {
            0 -> GREEN
            1 -> ORANGE
            else -> FAST
        }
        fun flush(seg: List<GeoPoint>, b: Int) {
            if (seg.size < 2) return
            val line = Polyline(map)
            line.outlinePaint.color = colorOf(b)
            line.outlinePaint.strokeWidth = 12f
            line.setPoints(seg)
            map.overlays.add(line)
            shownLines.add(line)
        }

        var cur = ArrayList<GeoPoint>()
        cur.add(GeoPoint(pts[0].lat, pts[0].lon))
        var curB = bucket(sp[1])
        for (i in 1 until pts.size) {
            val b = bucket(sp[i])
            val g = GeoPoint(pts[i].lat, pts[i].lon)
            if (b != curB) {
                flush(cur, curB)
                cur = arrayListOf(cur.last())
                curB = b
            }
            cur.add(g)
        }
        flush(cur, curB)

        follow = false
        map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) }), true, dp(60))
        map.invalidate()
        toast("🟢 مشي   🟠 دراجة/جري   🔴 مركبة")
    }

    private fun exportTrip(t: Trip) {
        val pts = db.points(t.id)
        val dir = File(cacheDir, "gpx").apply { mkdirs() }
        val file = File(dir, "trip_${t.id}.gpx")
        val name = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t.start))
        Gpx.write(file, name, pts)
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/gpx+xml"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "تصدير الرحلة"))
    }

    private fun deleteTrip(t: Trip) {
        if (t.id == TrackingService.tripId) {
            toast("أوقف التسجيل أولاً")
            return
        }
        AlertDialog.Builder(this)
            .setMessage("حذف هالرحلة نهائياً؟")
            .setPositiveButton("حذف") { _, _ ->
                db.deleteTrip(t.id)
                clearShownTrip()
                map.invalidate()
                computeToday()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- الخريطة بدون إنترنت ----------------

    private fun showOfflineHelp() {
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val tv = TextView(this).apply {
            text = "سيرفرات OpenStreetMap ما بتسمح بتحميل الخرائط دفعة وحدة، " +
                "فالتطبيق بيحفظ تلقائياً أي جزء من الخريطة بتشوفه.\n\n" +
                "الطريقة: وانت عندك إنترنت، حرّك الخريطة وقرّب وبعّد على المناطق اللي رح تروحلها. " +
                "كل جزء بتشوفه بينحفظ بالموبايل.\n\n" +
                "بعدها فعّل «وضع بدون إنترنت» وبتضل هالمناطق ظاهرة."
            textSize = 14f
            setTextColor(ink)
            setPadding(dp(24), dp(12), dp(24), dp(4))
        }
        val sw = Switch(this).apply {
            text = "وضع بدون إنترنت"
            textSize = 15f
            setTextColor(ink)
            isChecked = prefs.getBoolean("offline", false)
            setPadding(dp(24), dp(10), dp(24), dp(10))
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("offline", on).apply()
                map.setUseDataConnection(!on)
                map.invalidate()
            }
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv)
        box.addView(sw)
        AlertDialog.Builder(this)
            .setTitle("الخريطة بدون إنترنت")
            .setView(box)
            .setPositiveButton("تمام", null)
            .show()
    }

    // ---------------- صلاحيات وأدوات ----------------

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasLocation()) startLocation() else toast("التطبيق بحاجة لصلاحية الموقع ليشتغل")
    }

    private fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun pressable(color: Int, radiusDp: Int, rippleColor: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(rippleColor), roundBg(color, radiusDp), roundBg(Color.WHITE, radiusDp))

    private fun cell(value: TextView, caption: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        value.apply {
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            gravity = Gravity.CENTER
            text = "—"
        }
        addView(value)
        addView(TextView(context).apply {
            text = caption
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
        })
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }

    private fun tile(icon: String, label: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = pressable(tileBg, 14, ripple)
        setPadding(0, dp(10), 0, dp(10))
        isClickable = true
        setOnClickListener { onClick() }
        addView(TextView(context).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
        })
        addView(TextView(context).apply {
            text = label
            textSize = 12f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        })
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    /** صف من 4 خانات؛ اللي ناقص بينعبّى بفراغ. */
    private fun rowOf(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(6), 0, 0)
        v.forEach { addView(it) }
        for (i in v.size until 4) {
            addView(View(context).apply {
                layoutParams = LinearLayout.LayoutParams(0, 0, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
            })
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
