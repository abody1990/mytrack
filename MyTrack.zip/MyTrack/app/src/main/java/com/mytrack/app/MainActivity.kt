package com.mytrack.app

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.location.LocationManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يرسم موقعك على الخريطة: صورتك (دائرية) إذا اخترتها، أو نقطة زرقا. */
class MeOverlay(context: Context) : Overlay() {
    var location: GeoPoint? = null
    var avatar: Bitmap? = null
    private val pt = Point()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = context.resources.displayMetrics.density

    override fun draw(c: Canvas, osmv: MapView, shadow: Boolean) {
        if (shadow) return
        val loc = location ?: return
        osmv.projection.toPixels(loc, pt)
        val x = pt.x.toFloat()
        val y = pt.y.toFloat()
        val a = avatar
        if (a != null) {
            c.drawBitmap(a, x - a.width / 2f, y - a.height / 2f, null)
        } else {
            val r = 9 * d
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#332563EB")
            c.drawCircle(x, y, r * 2.4f, paint)
            paint.color = Color.WHITE
            c.drawCircle(x, y, r * 1.3f, paint)
            paint.color = Color.parseColor("#2563EB")
            c.drawCircle(x, y, r, paint)
        }
    }
}

class MainActivity : AppCompatActivity() {

    private companion object {
        val GREEN = Color.parseColor("#1B9E5A")
        val RED = Color.parseColor("#D93636")
        val INK = Color.parseColor("#1F2937")
        val MUTED = Color.parseColor("#6B7280")
        val TILE_BG = Color.parseColor("#F1F5F9")
    }

    private lateinit var map: MapView
    private lateinit var db: TrackDb
    private lateinit var provider: GpsMyLocationProvider
    private lateinit var meOverlay: MeOverlay
    private lateinit var btnRec: Button
    private lateinit var status: TextView
    private lateinit var sub: TextView

    private var liveLine: Polyline? = null
    private var shownLine: Polyline? = null
    private var follow = true
    private var myLoc: GeoPoint? = null
    private var centered = false

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) saveAvatar(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // سجّل أي انهيار بملف عشان نعرض سببه بالفتحة الجاية
        val crashFile = File(filesDir, "crash.txt")
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { crashFile.writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        // كل شي (الخرائط المخزّنة) بمجلد التطبيق، ما بنحتاج صلاحية تخزين
        val base = File(getExternalFilesDir(null), "osmdroid")
        File(base, "tiles").mkdirs()
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = base
            osmdroidTileCache = File(base, "tiles")
            tileFileSystemCacheMaxBytes = 2L * 1024 * 1024 * 1024
            tileFileSystemCacheTrimBytes = 1500L * 1024 * 1024
            setExpirationOverrideDuration(30L * 24 * 3600 * 1000)
        }

        db = TrackDb(this)
        provider = GpsMyLocationProvider(this)
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            controller.setZoom(15.0)
            controller.setCenter(GeoPoint(33.5138, 36.2765))
            setUseDataConnection(!prefs.getBoolean("offline", false))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_MOVE) follow = false
                false
            }
        }
        meOverlay = MeOverlay(this)
        loadAvatar()
        map.overlays.add(meOverlay)

        // ----- الواجهة -----
        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                val r = dp(24).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            elevation = dp(10).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }

        status = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(INK)
        }
        sub = TextView(this).apply {
            textSize = 13f
            setTextColor(MUTED)
            setPadding(0, dp(2), 0, dp(10))
        }
        btnRec = Button(this).apply {
            isAllCaps = false
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            stateListAnimator = null
            setOnClickListener { toggleRecording() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(54))
        }

        val tiles = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(2))
        }
        tiles.addView(tile("📂", "رحلاتي") { showTrips() })
        tiles.addView(tile("📍", "موقعي") { goToMe() })
        tiles.addView(tile("🖼", "صورتي") { avatarMenu() })
        tiles.addView(tile("🗺", "بدون نت") { showOfflineHelp() })

        val offlineSwitch = Switch(this).apply {
            text = "وضع بدون إنترنت"
            textSize = 14f
            setTextColor(INK)
            isChecked = prefs.getBoolean("offline", false)
            setPadding(dp(4), dp(8), dp(4), 0)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("offline", on).apply()
                map.setUseDataConnection(!on)
                map.invalidate()
            }
        }

        panel.addView(status)
        panel.addView(sub)
        panel.addView(btnRec)
        panel.addView(tiles)
        panel.addView(offlineSwitch)

        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        if (crashFile.exists()) {
            val text = try { crashFile.readText().take(1500) } catch (_: Throwable) { "" }
            crashFile.delete()
            AlertDialog.Builder(this)
                .setTitle("التطبيق سكّر المرة الماضية")
                .setMessage(text)
                .setPositiveButton("تمام", null)
                .show()
        } else if (!hasLocation()) {
            askPermissions()
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        startLocation()
        TrackingService.onUpdate = { updateUi() }
        updateUi()
    }

    override fun onPause() {
        super.onPause()
        TrackingService.onUpdate = null
        provider.stopLocationProvider()
        map.onPause()
    }

    // ---------------- الموقع الحالي ----------------

    private fun startLocation() {
        if (!hasLocation()) return
        try {
            provider.startLocationProvider(IMyLocationConsumer { l, _ ->
                if (l != null) onMyLocation(GeoPoint(l.latitude, l.longitude))
            })
            provider.lastKnownLocation?.let { onMyLocation(GeoPoint(it.latitude, it.longitude)) }
        } catch (_: SecurityException) {
        }
    }

    private fun onMyLocation(g: GeoPoint) {
        myLoc = g
        meOverlay.location = g
        if (!centered) {
            centered = true
            map.controller.setZoom(17.0)
            map.controller.setCenter(g)
        }
        map.postInvalidate()
    }

    private fun goToMe() {
        follow = true
        val loc = myLoc
        if (loc != null) {
            map.controller.animateTo(loc)
            map.controller.setZoom(17.0)
        } else {
            toast("لسا ما التقط الـ GPS موقعك، انتظر شوي")
        }
    }

    // ---------------- صورتك على الخريطة ----------------

    private fun avatarFile() = File(filesDir, "avatar.png")

    private fun avatarMenu() {
        val has = avatarFile().exists()
        val items = if (has) arrayOf("اختيار صورة جديدة", "إزالة الصورة") else arrayOf("اختيار صورة من المعرض")
        AlertDialog.Builder(this)
            .setTitle("صورتك على الخريطة")
            .setItems(items) { _, i ->
                if (i == 0) pickImage.launch("image/*") else removeAvatar()
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun loadAvatar() {
        val f = avatarFile()
        meOverlay.avatar = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun removeAvatar() {
        avatarFile().delete()
        meOverlay.avatar = null
        map.invalidate()
        toast("رجعت العلامة الزرقا")
    }

    private fun saveAvatar(uri: Uri) {
        try {
            val src = loadBitmap(uri)
            if (src == null) {
                toast("ما قدرت أفتح الصورة")
                return
            }
            val out = makeAvatar(src, dp(56))
            avatarFile().outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            meOverlay.avatar = out
            map.invalidate()
            toast("تم! صورتك صارت على الخريطة")
        } catch (t: Throwable) {
            toast("خطأ: ${t.javaClass.simpleName}")
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (_: Throwable) {
            1
        }
        val deg = when (orientation) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    /** يقصّ الصورة مربع من النص ويحوّلها لدائرة بإطار أبيض. */
    private fun makeAvatar(src: Bitmap, size: Int): Bitmap {
        val border = maxOf(3, size / 14)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = size / 2f
        p.color = Color.WHITE
        c.drawCircle(r, r, r, p)

        val s = minOf(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        val inner = size - border * 2
        val scaled = Bitmap.createScaledBitmap(square, inner, inner, true)
        val shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        shader.setLocalMatrix(Matrix().apply { setTranslate(border.toFloat(), border.toFloat()) })
        p.shader = shader
        c.drawCircle(r, r, r - border, p)
        return out
    }

    // ---------------- التسجيل ----------------

    private fun toggleRecording() {
        if (TrackingService.recording) {
            startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
            return
        }
        if (!hasLocation()) {
            askPermissions()
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            toast("فعّل الـ GPS من الإعدادات")
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        follow = true
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
    }

    private fun updateUi() {
        val rec = TrackingService.recording
        btnRec.text = if (rec) "⏹  إيقاف التسجيل" else "⏺  ابدأ التسجيل"
        btnRec.background = pressable(if (rec) RED else GREEN, 16, 0x33FFFFFF)

        val pts = TrackingService.live.toList()
        if (rec || pts.isNotEmpty()) {
            val line = liveLine ?: Polyline(map).also {
                it.outlinePaint.color = Color.RED
                it.outlinePaint.strokeWidth = 10f
                map.overlays.add(it)
                liveLine = it
            }
            line.setPoints(pts)
        }
        when {
            rec -> {
                status.text = "🔴 جاري التسجيل"
                sub.text = "${pts.size} نقطة  •  ${fmtDist(TrackingService.distance)}"
                if (follow && pts.isNotEmpty()) map.controller.animateTo(pts.last())
            }
            pts.isNotEmpty() -> {
                status.text = "✔ تم حفظ الرحلة"
                sub.text = "المسافة ${fmtDist(TrackingService.distance)}  •  شوفها من «رحلاتي»"
            }
            else -> {
                status.text = "جاهز للتسجيل"
                sub.text = "اضغط ابدأ لتسجيل مسارك"
            }
        }
        map.invalidate()
    }

    // ---------------- الرحلات ----------------

    private fun showTrips() {
        val trips = db.trips()
        if (trips.isEmpty()) {
            toast("ما في رحلات محفوظة")
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        val labels = trips.map { "${fmt.format(Date(it.start))}  •  ${it.count} نقطة" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("رحلاتي")
            .setItems(labels) { _, i -> tripActions(trips[i]) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun tripActions(t: Trip) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("عرض على الخريطة", "تصدير GPX (مشاركة)", "حذف")) { _, i ->
                when (i) {
                    0 -> showTrip(t)
                    1 -> exportTrip(t)
                    2 -> deleteTrip(t)
                }
            }
            .show()
    }

    private fun showTrip(t: Trip) {
        val pts = db.points(t.id).map { GeoPoint(it.lat, it.lon) }
        if (pts.size < 2) {
            toast("الرحلة قصيرة جداً")
            return
        }
        shownLine?.let { map.overlays.remove(it) }
        shownLine = Polyline(map).also {
            it.outlinePaint.color = Color.BLUE
            it.outlinePaint.strokeWidth = 10f
            it.setPoints(pts)
            map.overlays.add(it)
        }
        follow = false
        map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, dp(60))
        map.invalidate()
    }

    private fun exportTrip(t: Trip) {
        val pts = db.points(t.id)
        val dir = File(cacheDir, "gpx").apply { mkdirs() }
        val file = File(dir, "trip_${t.id}.gpx")
        val name = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t.start))
        Gpx.write(file, name, pts)
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/gpx+xml"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "تصدير الرحلة"))
    }

    private fun deleteTrip(t: Trip) {
        if (t.id == TrackingService.tripId) {
            toast("أوقف التسجيل أولاً")
            return
        }
        AlertDialog.Builder(this)
            .setMessage("حذف هالرحلة نهائياً؟")
            .setPositiveButton("حذف") { _, _ ->
                db.deleteTrip(t.id)
                shownLine?.let { map.overlays.remove(it) }
                shownLine = null
                map.invalidate()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- الخريطة بدون إنترنت ----------------

    private fun showOfflineHelp() {
        AlertDialog.Builder(this)
            .setTitle("الخريطة بدون إنترنت")
            .setMessage(
                "سيرفرات OpenStreetMap ما بتسمح بتحميل الخرائط دفعة وحدة، " +
                    "فالتطبيق بيحفظ تلقائياً أي جزء من الخريطة بتشوفه.\n\n" +
                    "الطريقة: وانت عندك إنترنت، حرّك الخريطة وقرّب وبعّد على المناطق اللي رح تروحلها. " +
                    "كل جزء بتشوفه بينحفظ بالموبايل.\n\n" +
                    "بعدها فعّل «وضع بدون إنترنت» وبتضل هالمناطق ظاهرة."
            )
            .setPositiveButton("تمام", null)
            .show()
    }

    // ---------------- صلاحيات وأدوات ----------------

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasLocation()) startLocation() else toast("التطبيق بحاجة لصلاحية الموقع ليشتغل")
    }

    private fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun pressable(color: Int, radiusDp: Int, rippleColor: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(rippleColor), roundBg(color, radiusDp), roundBg(Color.WHITE, radiusDp))

    private fun tile(icon: String, label: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = pressable(TILE_BG, 14, 0x22000000)
        setPadding(0, dp(10), 0, dp(10))
        isClickable = true
        setOnClickListener { onClick() }
        addView(TextView(context).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
        })
        addView(TextView(context).apply {
            text = label
            textSize = 12f
            setTextColor(INK)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        })
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun fmtDist(m: Float) =
        if (m < 1000) "${m.toInt()} م" else String.format(Locale.US, "%.2f كم", m / 1000)
}
