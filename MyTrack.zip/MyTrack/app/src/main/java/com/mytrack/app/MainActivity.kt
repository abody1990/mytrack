package com.mytrack.app

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var db: TrackDb
    private lateinit var me: MyLocationNewOverlay
    private lateinit var btnRec: Button
    private lateinit var status: TextView

    private var liveLine: Polyline? = null
    private var shownLine: Polyline? = null
    private var follow = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // كل شي (الخرائط المخزّنة + ملفات الخرائط الجاهزة) بمجلد التطبيق، ما بنحتاج صلاحية تخزين
        val base = File(getExternalFilesDir(null), "osmdroid")
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = base
            osmdroidTileCache = File(base, "tiles")
            tileFileSystemCacheMaxBytes = 2L * 1024 * 1024 * 1024
            tileFileSystemCacheTrimBytes = 1500L * 1024 * 1024
        }

        db = TrackDb(this)
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            controller.setZoom(15.0)
            controller.setCenter(GeoPoint(33.5138, 36.2765))
            setUseDataConnection(!prefs.getBoolean("offline", false))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_MOVE) follow = false
                false
            }
        }
        me = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        map.overlays.add(me)

        // ----- الواجهة -----
        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEEFFFFFF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        status = TextView(this).apply {
            text = "جاهز"
            textSize = 15f
            setTextColor(Color.BLACK)
        }
        panel.addView(status)

        val offlineSwitch = Switch(this).apply {
            text = "وضع بدون إنترنت (الخرائط المحفوظة فقط)"
            isChecked = prefs.getBoolean("offline", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("offline", on).apply()
                map.setUseDataConnection(!on)
                map.invalidate()
            }
        }
        panel.addView(offlineSwitch)

        btnRec = button("⏺ ابدأ التسجيل") { toggleRecording() }
        val row1 = row(btnRec, button("📂 رحلاتي") { showTrips() })
        val row2 = row(
            button("📍 موقعي") { goToMe() },
            button("⬇ تحميل المنطقة") { downloadArea() }
        )
        panel.addView(row1)
        panel.addView(row2)

        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        if (!hasLocation()) askPermissions()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLocation()) me.enableMyLocation()
        TrackingService.onUpdate = { updateUi() }
        updateUi()
    }

    override fun onPause() {
        super.onPause()
        TrackingService.onUpdate = null
        me.disableMyLocation()
        map.onPause()
    }

    // ---------------- التسجيل ----------------

    private fun toggleRecording() {
        if (TrackingService.recording) {
            startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
            return
        }
        if (!hasLocation()) {
            askPermissions()
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            toast("فعّل الـ GPS من الإعدادات")
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        follow = true
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
    }

    private fun updateUi() {
        val rec = TrackingService.recording
        btnRec.text = if (rec) "⏹ إيقاف التسجيل" else "⏺ ابدأ التسجيل"
        val pts = TrackingService.live.toList()
        if (rec || pts.isNotEmpty()) {
            val line = liveLine ?: Polyline(map).also {
                it.outlinePaint.color = Color.RED
                it.outlinePaint.strokeWidth = 10f
                map.overlays.add(it)
                liveLine = it
            }
            line.setPoints(pts)
        }
        if (rec) {
            status.text = "جاري التسجيل • ${pts.size} نقطة • ${fmtDist(TrackingService.distance)}"
            if (follow && pts.isNotEmpty()) map.controller.animateTo(pts.last())
        } else {
            status.text = if (pts.isEmpty()) "جاهز" else "تم حفظ الرحلة • ${fmtDist(TrackingService.distance)}"
        }
        map.invalidate()
    }

    private fun goToMe() {
        follow = true
        val loc = me.myLocation
        if (loc != null) {
            map.controller.animateTo(loc)
            map.controller.setZoom(17.0)
        } else {
            toast("لسا ما التقط الـ GPS موقعك، انتظر شوي")
        }
    }

    // ---------------- الرحلات ----------------

    private fun showTrips() {
        val trips = db.trips()
        if (trips.isEmpty()) {
            toast("ما في رحلات محفوظة")
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        val labels = trips.map { "${fmt.format(Date(it.start))}  •  ${it.count} نقطة" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("رحلاتي")
            .setItems(labels) { _, i -> tripActions(trips[i]) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun tripActions(t: Trip) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("عرض على الخريطة", "تصدير GPX (مشاركة)", "حذف")) { _, i ->
                when (i) {
                    0 -> showTrip(t)
                    1 -> exportTrip(t)
                    2 -> deleteTrip(t)
                }
            }
            .show()
    }

    private fun showTrip(t: Trip) {
        val pts = db.points(t.id).map { GeoPoint(it.lat, it.lon) }
        if (pts.size < 2) {
            toast("الرحلة قصيرة جداً")
            return
        }
        shownLine?.let { map.overlays.remove(it) }
        shownLine = Polyline(map).also {
            it.outlinePaint.color = Color.BLUE
            it.outlinePaint.strokeWidth = 10f
            it.setPoints(pts)
            map.overlays.add(it)
        }
        follow = false
        map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, dp(60))
        map.invalidate()
    }

    private fun exportTrip(t: Trip) {
        val pts = db.points(t.id)
        val dir = File(cacheDir, "gpx").apply { mkdirs() }
        val file = File(dir, "trip_${t.id}.gpx")
        val name = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t.start))
        Gpx.write(file, name, pts)
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/gpx+xml"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "تصدير الرحلة"))
    }

    private fun deleteTrip(t: Trip) {
        if (t.id == TrackingService.tripId) {
            toast("أوقف التسجيل أولاً")
            return
        }
        AlertDialog.Builder(this)
            .setMessage("حذف هالرحلة نهائياً؟")
            .setPositiveButton("حذف") { _, _ ->
                db.deleteTrip(t.id)
                shownLine?.let { map.overlays.remove(it) }
                shownLine = null
                map.invalidate()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- تحميل الخريطة للاستخدام بدون إنترنت ----------------

    private fun downloadArea() {
        val box = map.boundingBox
        val zMin = map.zoomLevelDouble.toInt()
        val zMax = minOf(zMin + 3, 18)
        val cm = CacheManager(map)
        val n = cm.possibleTilesInArea(box, zMin, zMax)
        if (n > 8000) {
            toast("المنطقة كبيرة ($n بلاطة). قرّب الخريطة أكتر وجرّب مرة ثانية")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("تحميل الخريطة")
            .setMessage("رح يتحمّل حوالي $n بلاطة (~${n * 20 / 1024 + 1} ميغا) من المنطقة الظاهرة بزومات $zMin–$zMax. لازم يكون في إنترنت هلأ.")
            .setPositiveButton("تحميل") { _, _ ->
                cm.downloadAreaAsync(this, box, zMin, zMax, object : CacheManager.CacheManagerCallback {
                    override fun onTaskComplete() = runOnUiThread {
                        status.text = "اكتمل تحميل المنطقة ✔"
                    }
                    override fun onTaskFailed(errors: Int) = runOnUiThread {
                        status.text = "انتهى التحميل مع $errors أخطاء (تأكد من الإنترنت)"
                    }
                    override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) =
                        runOnUiThread { status.text = "جاري التحميل… $progress / $n" }
                    override fun downloadStarted() = runOnUiThread { status.text = "بدأ التحميل…" }
                    override fun setPossibleTilesInArea(total: Int) {}
                })
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- صلاحيات وأدوات ----------------

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasLocation()) me.enableMyLocation() else toast("التطبيق بحاجة لصلاحية الموقع ليشتغل")
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }

    private fun row(vararg views: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun fmtDist(m: Float) =
        if (m < 1000) "${m.toInt()} م" else String.format(Locale.US, "%.2f كم", m / 1000)
}
