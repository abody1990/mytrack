package com.mytrack.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Trip(val id: Long, val start: Long, val end: Long, val count: Int)
data class Pt(val lat: Double, val lon: Double, val ele: Double, val t: Long, val spd: Double)
data class Visit(
    val id: Long, val trip: Long, val lat: Double, val lon: Double,
    val arrive: Long, val leave: Long, val name: String?, val type: String?
)

class TrackDb(c: Context) : SQLiteOpenHelper(c.applicationContext, "tracks.db", null, 2) {

    private val createVisits =
        "CREATE TABLE IF NOT EXISTS visits(id INTEGER PRIMARY KEY AUTOINCREMENT, trip INTEGER, " +
            "lat REAL, lon REAL, arrive INTEGER, leave INTEGER, name TEXT, type TEXT)"

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER, ended INTEGER)")
        d.execSQL(
            "CREATE TABLE points(id INTEGER PRIMARY KEY AUTOINCREMENT, trip INTEGER, " +
                "lat REAL, lon REAL, ele REAL, t INTEGER, spd REAL DEFAULT 0)"
        )
        d.execSQL("CREATE INDEX idx_points_trip ON points(trip)")
        d.execSQL(createVisits)
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            d.execSQL("ALTER TABLE points ADD COLUMN spd REAL DEFAULT 0")
            d.execSQL(createVisits)
        }
    }

    // ---------------- الرحلات ----------------

    fun startTrip(): Long {
        val v = ContentValues().apply { put("started", System.currentTimeMillis()) }
        return writableDatabase.insert("trips", null, v)
    }

    /** آخر رحلة لسا ما انتهت (مثلاً إذا النظام سكّر التطبيق). */
    fun openTrip(): Long? {
        readableDatabase.rawQuery("SELECT id FROM trips WHERE ended IS NULL ORDER BY id DESC LIMIT 1", null).use {
            return if (it.moveToFirst()) it.getLong(0) else null
        }
    }

    fun tripStart(id: Long): Long {
        readableDatabase.rawQuery("SELECT started FROM trips WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) it.getLong(0) else System.currentTimeMillis()
        }
    }

    fun endTrip(id: Long) {
        val db = writableDatabase
        val n = db.rawQuery("SELECT COUNT(*) FROM points WHERE trip=?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
        if (n == 0) {
            deleteTrip(id)
        } else {
            val v = ContentValues().apply { put("ended", System.currentTimeMillis()) }
            db.update("trips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun addPoint(trip: Long, lat: Double, lon: Double, ele: Double, t: Long, spd: Double) {
        val v = ContentValues().apply {
            put("trip", trip); put("lat", lat); put("lon", lon); put("ele", ele); put("t", t); put("spd", spd)
        }
        writableDatabase.insert("points", null, v)
    }

    fun points(trip: Long): List<Pt> {
        val out = ArrayList<Pt>()
        readableDatabase.rawQuery(
            "SELECT lat, lon, ele, t, spd FROM points WHERE trip=? ORDER BY id", arrayOf(trip.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(Pt(it.getDouble(0), it.getDouble(1), it.getDouble(2), it.getLong(3), it.getDouble(4)))
            }
        }
        return out
    }

    fun trips(): List<Trip> = queryTrips("1=1", emptyArray())

    fun tripsBetween(from: Long, to: Long): List<Trip> =
        queryTrips("started >= ? AND started < ?", arrayOf(from.toString(), to.toString()))

    private fun queryTrips(where: String, args: Array<String>): List<Trip> {
        val out = ArrayList<Trip>()
        readableDatabase.rawQuery(
            "SELECT id, started, ended, (SELECT COUNT(*) FROM points WHERE trip=trips.id) " +
                "FROM trips WHERE $where ORDER BY id DESC",
            args
        ).use {
            while (it.moveToNext()) out.add(Trip(it.getLong(0), it.getLong(1), it.getLong(2), it.getInt(3)))
        }
        return out
    }

    fun deleteTrip(id: Long) {
        val db = writableDatabase
        db.delete("points", "trip=?", arrayOf(id.toString()))
        db.delete("visits", "trip=?", arrayOf(id.toString()))
        db.delete("trips", "id=?", arrayOf(id.toString()))
    }

    // ---------------- الأماكن ----------------

    fun addVisit(trip: Long, lat: Double, lon: Double, arrive: Long, leave: Long): Long {
        val v = ContentValues().apply {
            put("trip", trip); put("lat", lat); put("lon", lon); put("arrive", arrive); put("leave", leave)
        }
        return writableDatabase.insert("visits", null, v)
    }

    fun updateVisitLeave(id: Long, leave: Long) {
        val v = ContentValues().apply { put("leave", leave) }
        writableDatabase.update("visits", v, "id=?", arrayOf(id.toString()))
    }

    fun setVisitName(id: Long, name: String, type: String) {
        val v = ContentValues().apply { put("name", name); put("type", type) }
        writableDatabase.update("visits", v, "id=?", arrayOf(id.toString()))
    }

    fun deleteVisit(id: Long) {
        writableDatabase.delete("visits", "id=?", arrayOf(id.toString()))
    }

    fun visits(from: Long, to: Long): List<Visit> = queryVisits(
        "arrive >= ? AND arrive < ? ORDER BY arrive", arrayOf(from.toString(), to.toString())
    )

    fun recentVisits(limit: Int): List<Visit> = queryVisits("1=1 ORDER BY arrive DESC LIMIT $limit", emptyArray())

    fun pendingVisits(): List<Visit> = queryVisits("name IS NULL ORDER BY arrive DESC LIMIT 20", emptyArray())

    private fun queryVisits(tail: String, args: Array<String>): List<Visit> {
        val out = ArrayList<Visit>()
        readableDatabase.rawQuery(
            "SELECT id, trip, lat, lon, arrive, leave, name, type FROM visits WHERE $tail", args
        ).use { out.addAll(readVisits(it)) }
        return out
    }

    private fun readVisits(it: Cursor): List<Visit> {
        val out = ArrayList<Visit>()
        while (it.moveToNext()) {
            out.add(
                Visit(
                    it.getLong(0), it.getLong(1), it.getDouble(2), it.getDouble(3),
                    it.getLong(4), it.getLong(5),
                    if (it.isNull(6)) null else it.getString(6),
                    if (it.isNull(7)) null else it.getString(7)
                )
            )
        }
        return out
    }
}
