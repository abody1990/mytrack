package com.mytrack.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Trip(val id: Long, val start: Long, val end: Long, val count: Int)
data class Pt(val lat: Double, val lon: Double, val ele: Double, val t: Long)

class TrackDb(c: Context) : SQLiteOpenHelper(c.applicationContext, "tracks.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER, ended INTEGER)")
        d.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY AUTOINCREMENT, trip INTEGER, lat REAL, lon REAL, ele REAL, t INTEGER)")
        d.execSQL("CREATE INDEX idx_points_trip ON points(trip)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun startTrip(): Long {
        val v = ContentValues().apply { put("started", System.currentTimeMillis()) }
        return writableDatabase.insert("trips", null, v)
    }

    /** آخر رحلة لسا ما انتهت (مثلاً إذا الجهاز سكّر التطبيق). */
    fun openTrip(): Long? {
        readableDatabase.rawQuery("SELECT id FROM trips WHERE ended IS NULL ORDER BY id DESC LIMIT 1", null).use {
            return if (it.moveToFirst()) it.getLong(0) else null
        }
    }

    fun endTrip(id: Long) {
        val db = writableDatabase
        val n = db.rawQuery("SELECT COUNT(*) FROM points WHERE trip=?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
        if (n == 0) {
            deleteTrip(id)
        } else {
            val v = ContentValues().apply { put("ended", System.currentTimeMillis()) }
            db.update("trips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun addPoint(trip: Long, lat: Double, lon: Double, ele: Double, t: Long) {
        val v = ContentValues().apply {
            put("trip", trip); put("lat", lat); put("lon", lon); put("ele", ele); put("t", t)
        }
        writableDatabase.insert("points", null, v)
    }

    fun points(trip: Long): List<Pt> {
        val out = ArrayList<Pt>()
        readableDatabase.rawQuery(
            "SELECT lat, lon, ele, t FROM points WHERE trip=? ORDER BY id", arrayOf(trip.toString())
        ).use {
            while (it.moveToNext()) out.add(Pt(it.getDouble(0), it.getDouble(1), it.getDouble(2), it.getLong(3)))
        }
        return out
    }

    fun trips(): List<Trip> {
        val out = ArrayList<Trip>()
        readableDatabase.rawQuery(
            "SELECT id, started, ended, (SELECT COUNT(*) FROM points WHERE trip=trips.id) FROM trips ORDER BY id DESC",
            null
        ).use {
            while (it.moveToNext()) out.add(Trip(it.getLong(0), it.getLong(1), it.getLong(2), it.getInt(3)))
        }
        return out
    }

    fun deleteTrip(id: Long) {
        val db = writableDatabase
        db.delete("points", "trip=?", arrayOf(id.toString()))
        db.delete("trips", "id=?", arrayOf(id.toString()))
    }
}
