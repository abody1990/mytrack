package com.mytrack.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Trip(val id: Long, val start: Long, val end: Long, val count: Int)
data class Pt(val lat: Double, val lon: Double, val ele: Double, val t: Long, val speed: Float = 0f, val place: String = "")

data class DailySummary(
    val tripCount: Int,
    val totalDistanceMeters: Double,
    val maxSpeedKmh: Float,
    val placesVisited: List<String>
)

class TrackDb(c: Context) : SQLiteOpenHelper(c.applicationContext, "tracks.db", null, 2) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER, ended INTEGER)")
        d.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY AUTOINCREMENT, trip INTEGER, lat REAL, lon REAL, ele REAL, t INTEGER, speed REAL DEFAULT 0, place TEXT DEFAULT '')")
        d.execSQL("CREATE INDEX idx_points_trip ON points(trip)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            try { d.execSQL("ALTER TABLE points ADD COLUMN speed REAL DEFAULT 0") } catch (_: Throwable) {}
            try { d.execSQL("ALTER TABLE points ADD COLUMN place TEXT DEFAULT ''") } catch (_: Throwable) {}
        }
    }

    fun startTrip(): Long {
        val v = ContentValues().apply { put("started", System.currentTimeMillis()) }
        return writableDatabase.insert("trips", null, v)
    }

    fun openTrip(): Long? {
        readableDatabase.rawQuery("SELECT id FROM trips WHERE ended IS NULL ORDER BY id DESC LIMIT 1", null).use {
            return if (it.moveToFirst()) it.getLong(0) else null
        }
    }

    fun endTrip(id: Long) {
        val db = writableDatabase
        val n = db.rawQuery("SELECT COUNT(*) FROM points WHERE trip=?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
        if (n == 0) {
            deleteTrip(id)
        } else {
            val v = ContentValues().apply { put("ended", System.currentTimeMillis()) }
            db.update("trips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun addPoint(trip: Long, lat: Double, lon: Double, ele: Double, t: Long, speed: Float = 0f, place: String = "") {
        val v = ContentValues().apply {
            put("trip", trip)
            put("lat", lat)
            put("lon", lon)
            put("ele", ele)
            put("t", t)
            put("speed", speed)
            put("place", place)
        }
        writableDatabase.insert("points", null, v)
    }

    fun points(trip: Long): List<Pt> {
        val out = ArrayList<Pt>()
        readableDatabase.rawQuery(
            "SELECT lat, lon, ele, t, speed, place FROM points WHERE trip=? ORDER BY id", arrayOf(trip.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(
                    Pt(
                        it.getDouble(0),
                        it.getDouble(1),
                        it.getDouble(2),
                        it.getLong(3),
                        it.getFloat(4),
                        it.getString(5) ?: ""
                    )
                )
            }
        }
        return out
    }

    fun trips(): List<Trip> {
        val out = ArrayList<Trip>()
        readableDatabase.rawQuery(
            "SELECT id, started, ended, (SELECT COUNT(*) FROM points WHERE trip=trips.id) FROM trips ORDER BY id DESC",
            null
        ).use {
            while (it.moveToNext()) out.add(Trip(it.getLong(0), it.getLong(1), it.getLong(2), it.getInt(3)))
        }
        return out
    }

    fun deleteTrip(id: Long) {
        val db = writableDatabase
        db.delete("points", "trip=?", arrayOf(id.toString()))
        db.delete("trips", "id=?", arrayOf(id.toString()))
    }

    fun getDailySummary(startTime: Long, endTime: Long): DailySummary {
        val outPts = ArrayList<Pt>()
        readableDatabase.rawQuery(
            "SELECT lat, lon, ele, t, speed, place FROM points WHERE t BETWEEN ? AND ? ORDER BY t ASC",
            arrayOf(startTime.toString(), endTime.toString())
        ).use {
            while (it.moveToNext()) {
                outPts.add(
                    Pt(
                        it.getDouble(0),
                        it.getDouble(1),
                        it.getDouble(2),
                        it.getLong(3),
                        it.getFloat(4),
                        it.getString(5) ?: ""
                    )
                )
            }
        }

        var totalDist = 0.0
        var maxSpeed = 0f
        val places = LinkedHashSet<String>()
        val loc1 = android.location.Location("")
        val loc2 = android.location.Location("")

        for (i in outPts.indices) {
            val p = outPts[i]
            if (p.speed > maxSpeed) maxSpeed = p.speed
            if (p.place.isNotBlank()) places.add(p.place)
            if (i > 0) {
                val prev = outPts[i - 1]
                loc1.latitude = prev.lat
                loc1.longitude = prev.lon
                loc2.latitude = p.lat
                loc2.longitude = p.lon
                val d = loc1.distanceTo(loc2)
                if (d < 5000) totalDist += d
            }
        }

        var tripCount = 0
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM trips WHERE started BETWEEN ? AND ?",
            arrayOf(startTime.toString(), endTime.toString())
        ).use {
            if (it.moveToFirst()) tripCount = it.getInt(0)
        }

        return DailySummary(tripCount, totalDist, maxSpeed, places.toList())
    }
}
