package com.mytrack.app

import android.content.Context
import android.location.Address
import android.location.Geocoder
import java.util.Locale
import java.util.concurrent.Executors

object PlaceResolver {
    private val executor = Executors.newSingleThreadExecutor()
    private var lastResolvedLat = 0.0
    private var lastResolvedLon = 0.0
    private var cachedPlace = ""

    fun resolve(context: Context, lat: Double, lon: Double, onResult: (String) -> Unit) {
        val dist = FloatArray(1)
        android.location.Location.distanceBetween(lat, lon, lastResolvedLat, lastResolvedLon, dist)
        if (cachedPlace.isNotEmpty() && dist[0] < 60f) {
            onResult(cachedPlace)
            return
        }

        executor.execute {
            try {
                val geocoder = Geocoder(context.applicationContext, Locale("ar"))
                @Suppress("DEPRECATION")
                val list: List<Address>? = geocoder.getFromLocation(lat, lon, 1)
                if (!list.isNullOrEmpty()) {
                    val addr = list[0]
                    val feature = addr.featureName
                    val street = addr.thoroughfare
                    val subLocality = addr.subLocality

                    val resolved = when {
                        !feature.isNullOrBlank() && !feature.matches(Regex("\\d+")) -> feature
                        !street.isNullOrBlank() -> street
                        !subLocality.isNullOrBlank() -> subLocality
                        else -> ""
                    }
                    if (resolved.isNotBlank()) {
                        lastResolvedLat = lat
                        lastResolvedLon = lon
                        cachedPlace = resolved
                        onResult(resolved)
                        return@execute
                    }
                }
            } catch (_: Throwable) {
            }
            onResult("")
        }
    }
}
