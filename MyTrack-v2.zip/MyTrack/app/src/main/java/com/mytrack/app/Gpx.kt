package com.mytrack.app

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Gpx {
    fun write(file: File, name: String, pts: List<Pt>) {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        file.bufferedWriter().use { w ->
            w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            w.write("<gpx version=\"1.1\" creator=\"MyTrack\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
            w.write("<trk><name>$name</name><trkseg>\n")
            for (p in pts) {
                w.write("<trkpt lat=\"${p.lat}\" lon=\"${p.lon}\"><ele>${p.ele}</ele><time>${iso.format(Date(p.t))}</time></trkpt>\n")
            }
            w.write("</trkseg></trk></gpx>\n")
        }
    }
}
