package com.mytrack.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

class TrackAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        when (action) {
            ScheduleManager.ACTION_AUTO_START -> {
                if (!TrackingService.recording) {
                    val svc = Intent(context, TrackingService::class.java)
                    ContextCompat.startForegroundService(context, svc)
                }
                ScheduleManager.scheduleNextAlarms(context)
            }
            ScheduleManager.ACTION_AUTO_STOP -> {
                if (TrackingService.recording) {
                    val svc = Intent(context, TrackingService::class.java).setAction(TrackingService.ACTION_STOP)
                    context.startService(svc)
                }
                ScheduleManager.scheduleNextAlarms(context)
            }
            ScheduleManager.ACTION_DAILY_REPORT -> {
                sendDailySummaryNotification(context)
                ScheduleManager.scheduleDailyReport(context)
            }
        }
    }

    private fun sendDailySummaryNotification(context: Context) {
        val db = TrackDb(context)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val startOfDay = cal.timeInMillis
        val endOfDay = System.currentTimeMillis()
        val summary = db.getDailySummary(startOfDay, endOfDay)

        val channelId = "daily_reports"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "التقرير اليومي", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        val km = summary.totalDistanceMeters / 1000.0
        val placesText = if (summary.placesVisited.isNotEmpty()) {
            "الأماكن: " + summary.placesVisited.take(5).joinToString("، ")
        } else {
            "لا توجد أماكن مسجلة"
        }

        val text = "المسافة اليوم: %.2f كم | أقصى سرعة: %.1f كم/س\n%s".format(Locale.US, km, summary.maxSpeedKmh, placesText)

        val openIntent = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("ملخص نشاطك اليومي")
            .setContentText("مشيت اليوم %.2f كم".format(Locale.US, km))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()

        nm.notify(1001, notif)
    }
}

object ScheduleManager {
    const val ACTION_AUTO_START = "com.mytrack.app.ACTION_AUTO_START"
    const val ACTION_AUTO_STOP = "com.mytrack.app.ACTION_AUTO_STOP"
    const val ACTION_DAILY_REPORT = "com.mytrack.app.ACTION_DAILY_REPORT"

    fun setSchedule(context: Context, enabled: Boolean, startHour: Int, startMin: Int, stopHour: Int, stopMin: Int) {
        val sp = context.getSharedPreferences("schedule_prefs", Context.MODE_PRIVATE)
        sp.edit()
            .putBoolean("enabled", enabled)
            .putInt("start_hour", startHour)
            .putInt("start_min", startMin)
            .putInt("stop_hour", stopHour)
            .putInt("stop_min", stopMin)
            .apply()

        if (enabled) {
            scheduleNextAlarms(context)
        } else {
            cancelAlarms(context)
        }
    }

    fun scheduleNextAlarms(context: Context) {
        val sp = context.getSharedPreferences("schedule_prefs", Context.MODE_PRIVATE)
        if (!sp.getBoolean("enabled", false)) return

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val startH = sp.getInt("start_hour", 8)
        val startM = sp.getInt("start_min", 0)
        val stopH = sp.getInt("stop_hour", 20)
        val stopM = sp.getInt("stop_min", 0)

        val now = System.currentTimeMillis()

        val calStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, startH)
            set(Calendar.MINUTE, startM)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
        }
        val startPi = PendingIntent.getBroadcast(
            context, 201, Intent(context, TrackAlarmReceiver::class.java).setAction(ACTION_AUTO_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calStart.timeInMillis, startPi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, calStart.timeInMillis, startPi)
            }
        } catch (_: SecurityException) {}

        val calStop = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, stopH)
            set(Calendar.MINUTE, stopM)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
        }
        val stopPi = PendingIntent.getBroadcast(
            context, 202, Intent(context, TrackAlarmReceiver::class.java).setAction(ACTION_AUTO_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calStop.timeInMillis, stopPi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, calStop.timeInMillis, stopPi)
            }
        } catch (_: SecurityException) {}
    }

    fun scheduleDailyReport(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(
            context, 301, Intent(context, TrackAlarmReceiver::class.java).setAction(ACTION_DAILY_REPORT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        } catch (_: SecurityException) {}
    }

    private fun cancelAlarms(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val startPi = PendingIntent.getBroadcast(
            context, 201, Intent(context, TrackAlarmReceiver::class.java).setAction(ACTION_AUTO_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        startPi?.let { am.cancel(it) }

        val stopPi = PendingIntent.getBroadcast(
            context, 202, Intent(context, TrackAlarmReceiver::class.java).setAction(ACTION_AUTO_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        stopPi?.let { am.cancel(it) }
    }
}
